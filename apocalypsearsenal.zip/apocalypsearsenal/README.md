# Apocalypse Arsenal

**A destruction-focused Minecraft mod — orbital bombardment, devastating bombs, and high-energy lasers.**

| | |
|---|---|
| Minecraft | 1.20.1 (Java Edition) |
| Mod loader | Forge 47.x (built against 47.2.0) |
| Java | 17 |
| Mod ID | `apocalypsearsenal` |
| Version | 1.0.0 |

---

## Installation

1. Install **Minecraft Forge 1.20.1** (version 47.x, e.g. 47.2.0 or newer) for your client/server.
2. Drop `apocalypsearsenal-1.20.1-1.0.0.jar` (from `build/libs/` or the `release/` folder) into your `mods/` folder.
3. Launch the game. The config file is generated at `config/apocalypsearsenal-common.toml` on first run.

No other mods are required.

---

## Weapons & Gameplay

Everything lives in the dedicated **Apocalypse Arsenal** creative tab. All recipes are crafted in a standard crafting table.

### Laser Rifle
* **Use:** hold right-click for a continuous high-energy beam.
* Vaporizes blocks along the beam path (per-shot block cap in config), carves a small crater at the impact point, ignites and heavily damages every mob on the line. Stops against unbreakable blocks.
* **Recipe:** redstone + iron + quartz.

### Industrial Mining Laser
* **Use:** hold right-click to excavate.
* Bores a large tunnel (default radius 2 → 5×5) along your look direction out to its configured range, capped per pulse. Mined blocks may drop items.
* **Recipe:** redstone + diamonds + quartz + iron.

### Fusion Bomb
* Throwable. 4-second fuse, then a massive crater-forming blast with fire, shockwave rings and a huge smoke column.
* **Recipe:** iron + TNT + diamond.

### Cluster Bomb
* Throwable. On detonation it bursts into a swarm of secondary charges (default 12) that scatter and explode on their own short fuses. The cluster chain is exactly one level deep — no infinite recursion.
* **Recipe:** TNT + a Fusion Bomb.

### Thermobaric Bomb
* Throwable. Larger blast than the fusion bomb, a clear **warning phase** (sirens, red pressure ring, chat warning for nearby players), plus delayed secondary detonations inside the blast zone. Secondaries never spawn more secondaries.
* **Recipe:** fire charges + TNT + a Fusion Bomb.

### Meteor Strike Beacon
* Throwable targeting beacon. Where it lands, a target marker and warning beam appear; after a countdown a meteor plummets from the sky and detonates on impact, leaving a burning crater.
* **Recipe:** obsidian + ender pearl + fire charge.

### Orbital Strike Cannon — *the signature weapon*
* **Right-click** where you want devastation: a targeting marker appears, a dramatic countdown plays (rising warning beeps, colored sky beam, expanding ground ring), then a vertical orbital energy beam slams down and bores a huge cylindrical crater with fire and shockwaves.
* **Modes** — cycle with **sneak + right-click**:
  * **SINGLE STRIKE** — one full-power strike on the aimed point.
  * **PRECISION STRIKE** — faster countdown, tighter radius, surgical.
  * **AREA BARRAGE** — several sequential strikes scattered around the target (default 3 strikes).
* 60-second item cooldown by default. Netherite + diamond + beacon recipe.
* The default orbital strike is substantially stronger than any bomb in the mod.

### Planetary Annihilator — *the endgame weapon*
* Right-click to mark an area: a long, loud charge-up (10 s) with a purple sky beam, then a colossal white annihilation beam and an enormous cylinder of destruction with a strict per-strike block cap. 5-minute cooldown.
* **Recipe:** 2 netherite ingots + 5 netherite blocks + a nether star + an Orbital Strike Cannon.

### Remote Detonation System
* **Remote Charge** (placeable block) + **Remote Detonator**.
* Sneak + right-click a placed charge **with the detonator** to link it to the detonator's channel.
* **Sneak + right-click in the air** to cycle the detonator's channel (0–9).
* **Right-click** to detonate every linked charge in range (capped, blasts staggered a few ticks apart). Charges destroyed by other explosions never chain-detonate — they just unlink.

---

## Crafting Progression

| Tier | Ingredients | Weapons |
|---|---|---|
| Basic | iron, redstone, quartz | Laser Rifle, Remote Detonator |
| Advanced | diamonds, TNT, obsidian, ender pearls | Mining Laser, Fusion/Cluster/Thermobaric Bombs, Meteor Beacon, Remote Charges |
| Military | netherite, beacon | Orbital Strike Cannon |
| Endgame | netherite blocks, nether star | Planetary Annihilator |

---

## Configuration

File: `config/apocalypsearsenal-common.toml` (generated on first launch; edit and restart, or reload with a config-reload mod). Highlights:

| Option | Default | Meaning |
|---|---|---|
| `global.globalDestructionMultiplier` | 1.0 | Multiplies every explosion radius (0.1–4.0). Crank it up in single-player. |
| `global.maxExplosionRadius` | 32 | **Hard cap** on any single explosion radius. |
| `global.maxBlocksPerStrike` | 60000 | **Hard cap** on blocks destroyed per strike. |
| `global.blocksPerTick` | 2048 | Per-tick server block-removal budget (batched destruction). |
| `global.dropChance` | 0.12 | Chance destroyed blocks drop items. |
| `global.fireEnabled` / `fireBlocksPerExplosion` | true / 48 | Fire after explosions. |
| `global.particleDensity` / `soundVolume` | 1.0 / 1.0 | Cosmetic intensity. |
| `global.maxActiveStrikes` | 8 | Concurrent orbital/annihilator strikes allowed. |
| `global.resistanceCutoff` | 1200 | Blocks above this blast resistance are immune (obsidian = 1200, so it *is* destructible by default; lower the value to protect it). |
| `global.protectedBlocks` | bedrock, barrier, command blocks, structure blocks, portals... | Never destroyed. |
| `global.whitelistBlocks` | (empty) | If non-empty, **only** these blocks may be destroyed by explosions. |
| `global.bombShape` | sphere | Destruction zone shape for the bomb family: `sphere`, `cylinder` or `cuboid`. |
| `laser.*` | range 96, damage 30, interval 8t, mining radius 1.5, 64 blocks/shot | Laser rifle tuning. |
| `miningLaser.*` | range 32, radius 2.0, interval 4t, 256 blocks/pulse | Mining laser tuning. |
| `bombs.*` | fusion 12r/80t, cluster 12 charges × 4r, thermobaric 16r + 4 secondaries | Bomb family tuning. |
| `meteor.*` | 10r, 100t countdown, 100 height | Meteor tuning. |
| `orbital.*` | 16r, 60t countdown, 3-strike barrage ×25t, 1200t cooldown, 250 dmg | Orbital cannon tuning. |
| `annihilator.*` | 24r, 200t charge-up, 6000t cooldown, 1000 dmg, 80000-block cap | Planetary Annihilator tuning. |
| `remote.*` | charge 6r, 16 charges max, 128 range | Remote detonation tuning. |

**Every value is re-clamped when used**, so a hand-edited config can never exceed the mod's safe technical limits (e.g. radius is always ≤ 64, block caps ≤ 250k, task queue is hard-capped).

---

## Technical Design Notes

* **Server-authoritative destruction.** All targeting is raytraced server-side; the client never sends coordinates or weapon parameters.
* **Budgeted block processing.** Huge strikes collect packed block positions (longs, never block states) and remove them through a per-tick budget (`blocksPerTick`), keeping ticks smooth even for 60 000-block strikes. Unloaded chunks are never touched.
* **Finite reactions.** Cluster charges and thermobaric secondaries are leaf effects; the scheduled-task queue is hard-capped (2048); remote charges unregister on removal and cannot chain-detonate.
* **No custom renderers, no shaders, no external libraries.** All visuals are server-synced vanilla particles and sounds — that also means multiplayer clients see every effect automatically.
* **Vanilla-only ingredients** in all recipes; the mod runs standalone on Forge.

## Building From Source

```bash
# Requires Java 17
./gradlew build
```

The compiled mod lands in `build/libs/apocalypsearsenal-1.20.1-1.0.0.jar`.

Smoke-test in a dev server: `./gradlew runServer` (accept `run/eula.txt` first).

Textures are procedurally generated: `python3 tools/gen_textures.py` regenerates every texture deterministically.

## License

MIT
