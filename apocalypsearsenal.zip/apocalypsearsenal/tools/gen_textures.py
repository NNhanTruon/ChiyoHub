#!/usr/bin/env python3
"""
Apocalypse Arsenal texture generator.

Generates all 16x16 item/block textures as real PNG files using only the
Python standard library (zlib + struct). Deterministic: same script,
same output. Run from the project root:

    python3 tools/gen_textures.py
"""
import os
import random
import struct
import zlib

SIZE = 16
OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                   "src", "main", "resources", "assets", "apocalypsearsenal", "textures")


# ----------------------------------------------------------------------------
# PNG writer (stdlib only)
# ----------------------------------------------------------------------------

def write_png(path, pixels):
    raw = b""
    for row in pixels:
        raw += b"\x00" + b"".join(struct.pack("4B", *px) for px in row)

    def chunk(ctype, data):
        return (struct.pack(">I", len(data)) + ctype + data +
                struct.pack(">I", zlib.crc32(ctype + data) & 0xFFFFFFFF))

    png = b"\x89PNG\r\n\x1a\n"
    png += chunk(b"IHDR", struct.pack(">IIBBBBB", SIZE, SIZE, 8, 6, 0, 0, 0))
    png += chunk(b"IDAT", zlib.compress(raw, 9))
    png += chunk(b"IEND", b"")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(png)
    print("wrote", path)


# ----------------------------------------------------------------------------
# Pixel helpers
# ----------------------------------------------------------------------------

def canvas(fill=(0, 0, 0, 0)):
    return [[list(fill) for _ in range(SIZE)] for _ in range(SIZE)]


def px(img, x, y, c):
    if 0 <= x < SIZE and 0 <= y < SIZE:
        img[y][x] = list(c)


def rect(img, x0, y0, x1, y1, c):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            px(img, x, y, c)


def disc(img, cx, cy, r, c):
    for y in range(SIZE):
        for x in range(SIZE):
            if (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                img[y][x] = list(c)


def outline(img, c):
    for i in range(SIZE):
        px(img, i, 0, c)
        px(img, i, SIZE - 1, c)
        px(img, 0, i, c)
        px(img, SIZE - 1, i, c)


def shade(c, factor):
    return (max(0, min(255, int(c[0] * factor))),
            max(0, min(255, int(c[1] * factor))),
            max(0, min(255, int(c[2] * factor))),
            c[3])


def noise_shade(img, c, base=0.88, spread=0.24, seed=1):
    """Fill every opaque pixel with brightness-noised color (metal look)."""
    rnd = random.Random(seed)
    for y in range(SIZE):
        for x in range(SIZE):
            if img[y][x][3] > 0:
                img[y][x] = shade(c, base + rnd.random() * spread)


# ----------------------------------------------------------------------------
# Palettes
# ----------------------------------------------------------------------------

STEEL = (96, 96, 104, 255)
STEEL_DARK = (52, 52, 60, 255)
RED = (212, 48, 32, 255)
RED_BRIGHT = (255, 90, 60, 255)
CYAN = (80, 220, 255, 255)
AMBER = (255, 176, 40, 255)
OLIVE = (86, 118, 66, 255)
OLIVE_LIGHT = (124, 160, 92, 255)
NAVY = (58, 74, 108, 255)
MAROON = (128, 34, 30, 255)
OBSIDIAN = (24, 18, 34, 255)
PURPLE = (128, 52, 200, 255)
WHITE = (240, 240, 245, 255)
GOLD = (232, 190, 60, 255)
BLACK = (20, 20, 24, 255)
KHAKI = (110, 112, 84, 255)
YELLOW = (255, 224, 80, 255)
ROCK = (110, 82, 60, 255)
ROCK_DARK = (74, 52, 40, 255)
FIRE = (255, 120, 20, 255)


# ----------------------------------------------------------------------------
# Texture painters
# ----------------------------------------------------------------------------

def tex_laser_rifle():
    img = canvas()
    # stock
    rect(img, 0, 6, 2, 9, STEEL_DARK)
    # body
    rect(img, 2, 6, 13, 9, STEEL)
    rect(img, 2, 6, 13, 6, shade(STEEL, 1.25))
    rect(img, 2, 9, 13, 9, shade(STEEL, 0.7))
    # scope
    rect(img, 4, 3, 8, 5, STEEL_DARK)
    px(img, 5, 4, RED_BRIGHT)
    px(img, 6, 4, RED)
    # grip
    rect(img, 3, 10, 5, 12, STEEL_DARK)
    # energy cell
    rect(img, 6, 7, 8, 8, RED)
    px(img, 7, 7, RED_BRIGHT)
    # muzzle + beam tip
    rect(img, 14, 7, 15, 8, RED)
    px(img, 15, 7, RED_BRIGHT)
    noise_shade(img, STEEL, seed=11)
    return img


def tex_mining_laser():
    img = canvas()
    # body
    rect(img, 1, 6, 12, 9, STEEL)
    rect(img, 1, 6, 12, 6, shade(STEEL, 1.25))
    rect(img, 1, 9, 12, 9, shade(STEEL, 0.7))
    # drill cone
    for i, x in enumerate(range(12, 16)):
        rect(img, x, 7 - i, x, 8 + i, GOLD if i % 2 == 0 else shade(GOLD, 0.75))
    # core glow
    rect(img, 4, 7, 6, 8, AMBER)
    px(img, 5, 7, YELLOW)
    # top handle
    rect(img, 5, 3, 8, 5, STEEL_DARK)
    # grip
    rect(img, 2, 10, 4, 12, STEEL_DARK)
    noise_shade(img, STEEL, seed=22)
    return img


def tex_fusion_bomb():
    img = canvas()
    disc(img, 7, 9, 5, OLIVE)
    # highlight
    disc(img, 5, 7, 2, OLIVE_LIGHT)
    # red band
    for x in range(16):
        for y in range(16):
            dx, dy = x - 7, y - 9
            if dx * dx + dy * dy <= 30 and 10 <= y <= 11:
                img[y][x] = list(RED)
    # fuse spark
    px(img, 7, 2, YELLOW)
    px(img, 7, 3, FIRE)
    px(img, 6, 3, AMBER)
    px(img, 8, 3, AMBER)
    px(img, 7, 4, MAROON)
    noise_shade(img, OLIVE, seed=33)
    return img


def tex_cluster_bomb():
    img = canvas()
    disc(img, 7, 9, 5, NAVY)
    # submunition dots
    for (cx, cy) in [(5, 7), (9, 7), (5, 11), (9, 11)]:
        disc(img, cx, cy, 1, AMBER)
        px(img, cx, cy, YELLOW)
    # stripe
    for x in range(16):
        for y in range(16):
            dx, dy = x - 7, y - 9
            if dx * dx + dy * dy <= 30 and y == 12:
                img[y][x] = list(RED)
    px(img, 7, 2, YELLOW)
    px(img, 7, 3, FIRE)
    noise_shade(img, NAVY, seed=44)
    return img


def tex_thermobaric_bomb():
    img = canvas()
    disc(img, 7, 9, 5, MAROON)
    # flame emblem
    pts = [(7, 12), (6, 11), (8, 11), (5, 10), (9, 10), (6, 9), (8, 9), (7, 8), (7, 7), (6, 6)]
    for x, y in pts:
        px(img, x, y, FIRE)
    px(img, 7, 6, YELLOW)
    # warning stripes top
    px(img, 7, 2, YELLOW)
    px(img, 6, 3, FIRE)
    px(img, 8, 3, FIRE)
    noise_shade(img, MAROON, seed=55)
    return img


def tex_meteor_beacon():
    img = canvas()
    # obsidian frame
    for y in range(SIZE):
        for x in range(SIZE):
            img[y][x] = list(OBSIDIAN if (x + y) % 2 == 0 else shade(OBSIDIAN, 1.4))
    outline(img, BLACK)
    # glowing core
    rect(img, 6, 6, 9, 9, FIRE)
    rect(img, 7, 7, 8, 8, YELLOW)
    px(img, 7, 7, WHITE)
    # crosshair
    for x in range(2, 14):
        px(img, x, 3, AMBER)
        px(img, x, 12, AMBER)
    for y in range(2, 14):
        px(img, 3, y, AMBER)
        px(img, 12, y, AMBER)
    # keep the core bright: repaint after crosshair
    rect(img, 6, 6, 9, 9, FIRE)
    rect(img, 7, 7, 8, 8, YELLOW)
    px(img, 7, 7, WHITE)
    return img


def tex_orbital_cannon():
    img = canvas()
    # main slab
    rect(img, 2, 5, 12, 11, STEEL)
    rect(img, 2, 5, 12, 5, shade(STEEL, 1.3))
    rect(img, 2, 11, 12, 11, shade(STEEL, 0.65))
    # antenna
    rect(img, 13, 1, 13, 5, STEEL_DARK)
    px(img, 13, 0, CYAN)
    # lens
    disc(img, 6, 8, 2, CYAN)
    px(img, 6, 8, WHITE)
    # control panel
    rect(img, 9, 7, 12, 10, STEEL_DARK)
    px(img, 10, 8, RED)
    px(img, 11, 8, YELLOW)
    px(img, 10, 9, CYAN)
    # handle
    rect(img, 4, 12, 6, 13, STEEL_DARK)
    outline_keep = None
    noise_shade(img, STEEL, seed=66)
    # re-paint bright lens after noise
    disc(img, 6, 8, 2, CYAN)
    px(img, 6, 8, WHITE)
    px(img, 13, 0, CYAN)
    return img


def tex_planetary_annihilator():
    img = canvas()
    # dark purple body
    rect(img, 1, 4, 14, 12, PURPLE)
    rect(img, 1, 4, 14, 4, shade(PURPLE, 1.35))
    rect(img, 1, 12, 14, 12, shade(PURPLE, 0.6))
    # gold trim
    outline(img, GOLD)
    # white star core
    disc(img, 7, 8, 2, WHITE)
    px(img, 7, 8, shade(WHITE, 1.0))
    px(img, 6, 7, shade(WHITE, 0.9))
    # energy vents
    for x in (3, 5, 9, 11):
        rect(img, x, 10, x, 11, shade(PURPLE, 1.8))
    px(img, 13, 2, WHITE)
    px(img, 12, 3, GOLD)
    noise_shade(img, PURPLE, base=0.92, spread=0.18, seed=77)
    outline(img, GOLD)
    disc(img, 7, 8, 2, WHITE)
    return img


def tex_remote_detonator():
    img = canvas()
    # casing
    rect(img, 3, 5, 12, 12, STEEL)
    rect(img, 3, 5, 12, 5, shade(STEEL, 1.3))
    # antenna
    rect(img, 11, 1, 11, 5, STEEL_DARK)
    px(img, 11, 0, RED)
    # big red button
    disc(img, 7, 9, 2, RED)
    px(img, 6, 8, RED_BRIGHT)
    # LED
    px(img, 4, 6, YELLOW)
    px(img, 5, 6, shade(YELLOW, 0.8))
    noise_shade(img, STEEL, seed=88)
    disc(img, 7, 9, 2, RED)
    px(img, 6, 8, RED_BRIGHT)
    px(img, 11, 0, RED)
    return img


def tex_meteor_core():
    img = canvas()
    disc(img, 8, 8, 6, ROCK)
    disc(img, 6, 6, 2, shade(ROCK, 1.35))
    # cracks
    rnd = random.Random(99)
    for _ in range(5):
        x, y = 4 + rnd.randrange(8), 4 + rnd.randrange(8)
        for _ in range(4):
            px(img, x, y, FIRE)
            x += rnd.randrange(-1, 2)
            y += rnd.randrange(-1, 2)
    # hot bottom
    for x in range(4, 12):
        px(img, x, 13, FIRE)
        px(img, x, 14, shade(FIRE, 0.8))
    noise_shade(img, ROCK, seed=100)
    # repaint cracks bright
    rnd = random.Random(99)
    for _ in range(5):
        x, y = 4 + rnd.randrange(8), 4 + rnd.randrange(8)
        for _ in range(4):
            px(img, x, y, FIRE)
            x += rnd.randrange(-1, 2)
            y += rnd.randrange(-1, 2)
    for x in range(4, 12):
        px(img, x, 13, FIRE)
    return img


def tex_remote_charge():
    img = canvas()
    # khaki explosive block
    rect(img, 0, 0, 15, 15, KHAKI)
    # hazard stripes
    for i in range(-16, 32, 4):
        for d in range(16):
            x = i + d
            y = d
            if 0 <= x < 16:
                img[y][x] = list(RED)
    # black frame
    outline(img, BLACK)
    # yellow center marker + detonator dot
    rect(img, 6, 6, 9, 9, YELLOW)
    disc(img, 7, 7, 1, BLACK)
    noise_shade(img, KHAKI, base=0.9, spread=0.2, seed=111)
    outline(img, BLACK)
    rect(img, 6, 6, 9, 9, YELLOW)
    disc(img, 7, 7, 1, BLACK)
    return img


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------

def main():
    items = {
        "laser_rifle": tex_laser_rifle,
        "mining_laser": tex_mining_laser,
        "fusion_bomb": tex_fusion_bomb,
        "cluster_bomb": tex_cluster_bomb,
        "thermobaric_bomb": tex_thermobaric_bomb,
        "meteor_beacon": tex_meteor_beacon,
        "orbital_cannon": tex_orbital_cannon,
        "planetary_annihilator": tex_planetary_annihilator,
        "remote_detonator": tex_remote_detonator,
        "meteor_core": tex_meteor_core,
    }
    for name, painter in items.items():
        write_png(os.path.join(OUT, "item", name + ".png"), painter())

    # The remote charge block and its item share one texture.
    write_png(os.path.join(OUT, "block", "remote_charge.png"), tex_remote_charge())

    print("All textures generated.")


if __name__ == "__main__":
    main()
