package com.apocalypsearsenal.destruction;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import com.apocalypsearsenal.Config;

import org.joml.Vector3f;

/**
 * Server-side state machine for the Orbital Strike Cannon and the
 * Planetary Annihilator.
 *
 * Lifecycle of one strike:
 *   delay (barrage sequencing) -> countdown (warning beam + beeps + ring)
 *   -> impact (sky beam flash + huge cylinder explosion) -> residual smoke.
 *
 * Every strike is a tick-driven object — no recursive scheduling, no
 * per-tick task spam — and the total number of concurrent strikes is
 * capped by the config.
 */
public final class OrbitalStrikeManager {

    private static final List<Strike> ACTIVE = new ArrayList<>();

    private static final class Strike {
        final ServerLevel level;
        final Vec3 target;
        final double radius;
        final float damage;
        final int countdown;
        final int beamWidth;
        final boolean fire;
        final boolean annihilator;
        final int maxBlocks;
        int delay;          // ticks before the countdown begins (barrage sequencing)
        int elapsed;        // ticks since countdown began
        boolean impacted;
        int postTicks;

        Strike(ServerLevel level, Vec3 target, double radius, float damage, int countdown,
               int beamWidth, boolean fire, boolean annihilator, int maxBlocks, int delay) {
            this.level = level;
            this.target = target;
            this.radius = radius;
            this.damage = damage;
            this.countdown = Math.max(10, countdown);
            this.beamWidth = beamWidth;
            this.fire = fire;
            this.annihilator = annihilator;
            this.maxBlocks = maxBlocks;
            this.delay = delay;
        }
    }

    private OrbitalStrikeManager() {
    }

    /**
     * Starts one orbital strike operation (possibly several sequential strikes
     * for barrage mode).
     *
     * @return false if the strike network is saturated (config cap reached)
     */
    public static boolean start(ServerLevel level, Player user, Vec3 target,
                                 boolean barrage, boolean precision, boolean annihilator) {
        double radius;
        int countdown;
        float damage;
        int beamWidth;
        int maxBlocks;

        if (annihilator) {
            radius = Config.annihilatorRadius();
            countdown = Config.annihilatorCountdown();
            damage = (float) Config.annihilatorDamage();
            beamWidth = 5;
            maxBlocks = Config.annihilatorMaxBlocksPerStrike();
        } else {
            radius = Config.orbitalRadius() * (precision ? 0.6 : 1.0);
            countdown = (int) (Config.orbitalCountdown() * (precision ? 0.5 : 1.0));
            damage = (float) Config.orbitalDamage();
            beamWidth = Config.orbitalBeamWidth();
            maxBlocks = Config.orbitalMaxBlocksPerStrike();
        }

        int strikes = (barrage && !annihilator) ? Config.orbitalStrikeCount() : 1;
        int interval = Config.orbitalStrikeInterval();
        double spread = Config.orbitalBarrageSpread();

        // Capacity check: refuse if this operation would exceed the strike cap.
        if (ACTIVE.size() + strikes > Config.maxActiveStrikes()) {
            return false;
        }

        for (int i = 0; i < strikes; i++) {
            Vec3 t = target;
            if (i > 0) {
                // Barrage: random offsets around the marked point.
                double ang = level.random.nextDouble() * Math.PI * 2.0;
                double dist = level.random.nextDouble() * spread;
                t = target.add(Math.cos(ang) * dist, 0, Math.sin(ang) * dist);
            }
            ACTIVE.add(new Strike(level, t, radius, damage, countdown, beamWidth,
                    Config.FIRE_ENABLED.get(), annihilator, maxBlocks, i * interval));
        }

        if (annihilator) {
            level.playSound(null, target.x, target.y, target.z,
                    SoundEvents.WITHER_SPAWN, SoundSource.HOSTILE, 3.0F, 0.5F);
        }
        return true;
    }

    public static void clear() {
        ACTIVE.clear();
    }

    /** Called at the end of every server tick. */
    public static void tick() {
        if (ACTIVE.isEmpty()) {
            return;
        }
        Iterator<Strike> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Strike s = it.next();
            if (s.level.getServer() == null) {
                it.remove();
                continue;
            }
            if (s.delay > 0) {
                s.delay--;
                continue;
            }
            if (!s.impacted) {
                tickCountdown(s);
            } else {
                tickResidual(s);
                if (s.postTicks > 80) {
                    it.remove();
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Countdown phase: warning beam, expanding marker ring, rising beeps.
    // ------------------------------------------------------------------

    private static void tickCountdown(Strike s) {
        // Absolute start event: dramatic opening sound.
        if (s.elapsed == 0) {
            s.level.playSound(null, s.target.x, s.target.y, s.target.z,
                    s.annihilator ? SoundEvents.ENDER_DRAGON_GROWL : SoundEvents.BEACON_ACTIVATE,
                    SoundSource.BLOCKS, 3.0F * (float) Config.soundVolume(), s.annihilator ? 0.4F : 0.6F);
        }

        s.elapsed++;
        if (s.elapsed % 5 != 0) {
            if (s.elapsed < s.countdown) {
                return;
            }
        }

        double progress = Mth.clamp((double) s.elapsed / s.countdown, 0.0, 1.0);

        // ---- Targeting beam from the sky ----
        double beamTop = Math.min(s.target.y + (s.annihilator ? 150 : 120),
                s.level.getMaxBuildHeight() - 2);
        // Color: orbital goes red -> white hot; annihilator goes purple -> white.
        Vector3f color = s.annihilator
                ? new Vector3f(0.55F + 0.45F * (float) progress, 0.05F + 0.25F * (float) progress, 0.95F)
                : new Vector3f(1.0F, (float) (0.15 + 0.85 * progress), (float) (0.05 + 0.95 * progress));
        DustParticleOptions dust = new DustParticleOptions(color, 2.5F);

        DestructionManager.beam(s.level, s.target, s.target.y + 1.5, beamTop, 4.0,
                s.beamWidth * DestructionManager.count(1), dust, 0);
        DestructionManager.beam(s.level, s.target, s.target.y + 1.5, beamTop, 8.0,
                DestructionManager.count(1), ParticleTypes.END_ROD, 0);

        // ---- Ground marker ring, expanding with progress ----
        double markerRadius = 1.5 + progress * s.radius * 0.7;
        DestructionManager.ring(s.level, s.target, markerRadius, s.target.y + 0.3,
                DestructionManager.count(24), ParticleTypes.FLAME, 0);
        DestructionManager.ring(s.level, s.target, markerRadius, s.target.y + 0.1,
                DestructionManager.count(24), dust, 0);

        // ---- Warning beeps, pitch rising as impact approaches ----
        if (s.elapsed % 15 == 0) {
            float pitch = 0.5F + (float) progress * 1.3F;
            s.level.playSound(null, s.target.x, s.target.y, s.target.z,
                    SoundEvents.BEACON_DEACTIVATE, SoundSource.BLOCKS,
                    1.5F * (float) Config.soundVolume(), pitch);
        }

        if (s.elapsed >= s.countdown) {
            impact(s);
        }
    }

    // ------------------------------------------------------------------
    // Impact phase
    // ------------------------------------------------------------------

    private static void impact(Strike s) {
        s.impacted = true;
        s.postTicks = 0;
        ServerLevel level = s.level;
        Vec3 t = s.target;
        float vol = (float) Config.soundVolume();

        // Dramatic sound stack.
        level.playSound(null, t.x, t.y, t.z, SoundEvents.LIGHTNING_BOLT_THUNDER,
                SoundSource.WEATHER, 6.0F * vol, 0.7F);
        level.playSound(null, t.x, t.y, t.z, SoundEvents.GENERIC_EXPLODE,
                SoundSource.BLOCKS, 6.0F * vol, 0.5F);

        // Sky beam flash: white column of light from orbit to the ground.
        double beamTop = Math.min(t.y + 150, level.getMaxBuildHeight() - 2);
        Vector3f white = new Vector3f(1.0F, 1.0F, 1.0F);
        DustParticleOptions whiteDust = new DustParticleOptions(white, 4.0F);
        DestructionManager.beam(level, t, t.y + 1, beamTop, 3.0,
                s.beamWidth * 2 * DestructionManager.count(1), whiteDust, 0.05);
        for (double y = t.y + 1; y < beamTop; y += 8) {
            level.sendParticles(ParticleTypes.FLASH, t.x, y, t.z, 1, 0.4, 0.4, 0.4, 0);
            level.sendParticles(ParticleTypes.FIREWORK, t.x, y, t.z,
                    DestructionManager.count(2), 0.5, 0.5, 0.5, 0.1);
        }

        // Ground impact visuals.
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, t.x, t.y + 1, t.z, 3, 1, 1, 1, 0);
        level.sendParticles(ParticleTypes.FLASH, t.x, t.y + 2, t.z, 3, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.END_ROD, t.x, t.y + 2, t.z,
                DestructionManager.count(40), 2, 2, 2, 0.2);

        // The orbital beam bores a vertical cylinder of destruction with a
        // crater underneath, capped by its own block budget.
        CustomExplosion.explode(level, t, s.radius, CustomExplosion.Shape.CYLINDER,
                s.fire, true, s.damage, 3.0, s.maxBlocks, null);
    }

    // ------------------------------------------------------------------
    // Post-impact: residual smoke column and embers.
    // ------------------------------------------------------------------

    private static void tickResidual(Strike s) {
        s.postTicks++;
        if (s.postTicks % 10 != 0) {
            return;
        }
        Vec3 t = s.target;
        s.level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, t.x, t.y + 2, t.z,
                DestructionManager.count(3), s.radius * 0.15, 1.5, s.radius * 0.15, 0.02);
        s.level.sendParticles(ParticleTypes.FLAME, t.x, t.y + 1, t.z,
                DestructionManager.count(4), s.radius * 0.2, 0.5, s.radius * 0.2, 0.05);
        if (s.postTicks % 30 == 0) {
            s.level.sendParticles(ParticleTypes.ASH, t.x, t.y + 8, t.z,
                    DestructionManager.count(20), s.radius * 0.5, 4, s.radius * 0.5, 0.02);
        }
    }
}
