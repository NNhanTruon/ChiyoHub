package com.apocalypsearsenal.destruction;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import com.apocalypsearsenal.ApocalypseArsenal;
import com.apocalypsearsenal.Config;

import it.unimi.dsi.fastutil.longs.LongArrayList;

/**
 * Server-side destruction scheduler.
 *
 * Large explosions never set thousands of blocks to air in a single tick.
 * Instead they enqueue block positions (packed into longs, not live block
 * states, so huge blasts stay memory-cheap) into batches which are drained
 * under a strict per-tick block budget. Delayed effects (shockwave rings,
 * secondary detonations, smoke columns) are scheduled tasks executed on the
 * server thread — with a hard cap on the number of pending tasks so nothing
 * can schedule itself into a runaway state.
 */
public final class DestructionManager {

    /** Hard cap for pending scheduled tasks, protects against recursive scheduling. */
    private static final int MAX_SCHEDULED_TASKS = 2048;

    public static final class Batch {
        final ServerLevel level;
        final long[] positions;
        int index;
        final float dropChance;
        @Nullable
        final Runnable onFinish;

        Batch(ServerLevel level, long[] positions, float dropChance, @Nullable Runnable onFinish) {
            this.level = level;
            this.positions = positions;
            this.dropChance = dropChance;
            this.onFinish = onFinish;
        }
    }

    public static final class Delayed {
        int ticks;
        final Runnable task;

        Delayed(int ticks, Runnable task) {
            this.ticks = Math.max(0, ticks);
            this.task = task;
        }
    }

    private static final List<Batch> BATCHES = new ArrayList<>();
    private static final List<Delayed> SCHEDULED = new ArrayList<>();

    private DestructionManager() {
    }

    // ------------------------------------------------------------------
    // API
    // ------------------------------------------------------------------

    /**
     * Queues a list of packed block positions for removal, drained over
     * several ticks under the configured per-tick budget.
     */
    public static void enqueue(ServerLevel level, long[] positions, float dropChance, @Nullable Runnable onFinish) {
        if (positions.length == 0) {
            if (onFinish != null) {
                onFinish.run();
            }
            return;
        }
        BATCHES.add(new Batch(level, positions, dropChance, onFinish));
    }

    /**
     * Queues a small spherical carve (used by the laser rifle impact).
     */
    public static void enqueueSphere(ServerLevel level, Vec3 center, double radius, int maxBlocks, float dropChance) {
        LongArrayList list = new LongArrayList();
        BlockPos c = BlockPos.containing(center);
        int ir = Mth.ceil(radius);
        double r2 = radius * radius;
        for (BlockPos pos : BlockPos.betweenClosed(c.offset(-ir, -ir, -ir), c.offset(ir, ir, ir))) {
            if (pos.distToCenterSqr(center.x, center.y, center.z) <= r2) {
                BlockState state = level.getBlockState(pos);
                if (!state.isAir() && BlockFilter.canDestroyForMining(level, pos, state)) {
                    list.add(pos.asLong());
                    if (list.size() >= maxBlocks) {
                        break;
                    }
                }
            }
        }
        enqueue(level, list.toLongArray(), dropChance, null);
    }

    /**
     * Schedules a task to run on the server thread after a delay (in ticks).
     * Silently dropped if the task queue is full — this is the guard that
     * makes infinite chain reactions impossible.
     */
    public static void schedule(int delayTicks, Runnable task) {
        if (SCHEDULED.size() >= MAX_SCHEDULED_TASKS) {
            ApocalypseArsenal.LOGGER.warn("DestructionManager: dropped scheduled task, queue is full");
            return;
        }
        SCHEDULED.add(new Delayed(delayTicks, task));
    }

    /** Clears all state. Called when the server stops. */
    public static void clearAll() {
        BATCHES.clear();
        SCHEDULED.clear();
        OrbitalStrikeManager.clear();
    }

    /** Called at the end of every server tick. */
    public static void tickAll() {
        tickScheduled();
        tickBatches();
        OrbitalStrikeManager.tick();
    }

    // ------------------------------------------------------------------
    // Internals
    // ------------------------------------------------------------------

    private static void tickScheduled() {
        if (SCHEDULED.isEmpty()) {
            return;
        }
        Iterator<Delayed> it = SCHEDULED.iterator();
        while (it.hasNext()) {
            Delayed d = it.next();
            d.ticks--;
            if (d.ticks <= 0) {
                it.remove();
                try {
                    d.task.run();
                } catch (Exception e) {
                    ApocalypseArsenal.LOGGER.error("DestructionManager: scheduled task failed", e);
                }
            }
        }
    }

    private static void tickBatches() {
        if (BATCHES.isEmpty()) {
            return;
        }
        int budget = Config.blocksPerTick();
        Iterator<Batch> it = BATCHES.iterator();
        while (it.hasNext() && budget > 0) {
            Batch b = it.next();
            // Drain this batch until the budget for this tick is spent.
            while (b.index < b.positions.length && budget > 0) {
                BlockPos pos = BlockPos.of(b.positions[b.index++]);
                budget--;
                // Never touch unloaded chunks — explosions only scar loaded terrain.
                if (!b.level.hasChunkAt(pos)) {
                    continue;
                }
                BlockState state = b.level.getBlockState(pos);
                if (state.isAir()) {
                    continue;
                }
                // Re-validate at removal time (protection could have changed).
                if (!BlockFilter.canDestroy(b.level, pos, state)) {
                    continue;
                }
                b.level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                if (b.dropChance > 0.0F && b.level.random.nextFloat() < b.dropChance) {
                    net.minecraft.world.level.block.Block.dropResources(state, b.level, pos);
                }
            }
            if (b.index >= b.positions.length) {
                it.remove();
                if (b.onFinish != null) {
                    try {
                        b.onFinish.run();
                    } catch (Exception e) {
                        ApocalypseArsenal.LOGGER.error("DestructionManager: batch finish hook failed", e);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Shared particle helpers (density-scaled, server-authoritative)
    // ------------------------------------------------------------------

    /** Scaled particle count based on the configured particle density. */
    public static int count(int base) {
        return Math.max(0, Mth.ceil(base * Config.particleDensity()));
    }

    /**
     * Draws a horizontal particle ring. Each particle is placed exactly
     * (count=0 in sendParticles sends one particle at the position).
     */
    public static void ring(ServerLevel level, Vec3 center, double radius, double y,
                           int points, ParticleOptions particle, double speed) {
        for (int i = 0; i < points; i++) {
            double angle = Math.PI * 2.0 * i / points;
            double x = center.x + Math.cos(angle) * radius;
            double z = center.z + Math.sin(angle) * radius;
            level.sendParticles(particle, x, y, z, 0, 0, 0, 0, speed);
        }
    }

    /** Vertical particle column (the classic "strike beam"). */
    public static void beam(ServerLevel level, Vec3 center, double fromY, double toY, double step,
                           int width, ParticleOptions particle, double speed) {
        for (double y = fromY; y <= toY; y += step) {
            for (int i = 0; i < width; i++) {
                double ox = (level.random.nextDouble() - 0.5) * 0.8;
                double oz = (level.random.nextDouble() - 0.5) * 0.8;
                level.sendParticles(particle, center.x + ox, y, center.z + oz, 0, 0, 0, 0, speed);
            }
        }
    }
}
