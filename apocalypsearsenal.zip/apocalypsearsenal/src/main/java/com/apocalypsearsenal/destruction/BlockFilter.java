package com.apocalypsearsenal.destruction;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

import com.apocalypsearsenal.Config;

/**
 * Decides which blocks a weapon may destroy.
 *
 * Rules (all checked server-side, never trusting client data):
 *  1. Air is never "destroyed".
 *  2. Unbreakable blocks (negative destroy speed: bedrock, barriers, portals...)
 *     are always immune.
 *  3. Blocks listed in {@code protectedBlocks} config are immune.
 *  4. If {@code whitelistBlocks} is non-empty, only whitelisted blocks may be
 *     destroyed by explosions.
 *  5. Blocks above the blast resistance cutoff are immune.
 */
public final class BlockFilter {

    private static volatile Set<ResourceLocation> protectedBlocks = Set.of();
    private static volatile Set<ResourceLocation> whitelistBlocks = Set.of();

    private BlockFilter() {
    }

    /** Rebuilds the cached sets from config. Called on config load/reload. */
    public static synchronized void reloadFromConfig() {
        protectedBlocks = parseIds(Config.PROTECTED_BLOCKS.get());
        whitelistBlocks = parseIds(Config.WHITELIST_BLOCKS.get());
    }

    private static Set<ResourceLocation> parseIds(List<String> raw) {
        Set<ResourceLocation> ids = new HashSet<>();
        for (String entry : raw) {
            String s = entry == null ? "" : entry.trim().toLowerCase(Locale.ROOT);
            if (s.isEmpty()) {
                continue;
            }
            ResourceLocation id = ResourceLocation.tryParse(s.contains(":") ? s : "minecraft:" + s);
            if (id != null) {
                ids.add(id);
            }
        }
        return ids;
    }

    /** @return true if this block may be destroyed by a weapon effect. */
    public static boolean canDestroy(Level level, BlockPos pos, BlockState state) {
        if (state.isAir()) {
            return false;
        }
        // Rule 2: unbreakable blocks (bedrock etc.) — destroy speed < 0.
        if (state.getDestroySpeed(level, pos) < 0.0F) {
            return false;
        }
        Block block = state.getBlock();
        ResourceLocation id = ForgeRegistries.BLOCKS.getKey(block);
        if (id == null) {
            return false;
        }
        // Rule 4: whitelist mode (only applies to explosion-style destruction; mining lasers
        // always pass through canDestroyForMining which skips the whitelist).
        if (!whitelistBlocks.isEmpty() && !whitelistBlocks.contains(id)) {
            return false;
        }
        // Rule 3: explicit protected blocks.
        if (protectedBlocks.contains(id)) {
            return false;
        }
        // Rule 5: blast resistance cutoff.
        return block.getExplosionResistance() <= Config.resistanceCutoff();
    }

    /** Same as {@link #canDestroy} but ignores the whitelist (mining tools must mine everything normal). */
    public static boolean canDestroyForMining(Level level, BlockPos pos, BlockState state) {
        if (state.isAir()) {
            return false;
        }
        if (state.getDestroySpeed(level, pos) < 0.0F) {
            return false;
        }
        Block block = state.getBlock();
        ResourceLocation id = ForgeRegistries.BLOCKS.getKey(block);
        if (id == null) {
            return false;
        }
        if (protectedBlocks.contains(id)) {
            return false;
        }
        return block.getExplosionResistance() <= Config.resistanceCutoff();
    }
}
