package com.apocalypsearsenal.destruction;

import javax.annotation.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import com.apocalypsearsenal.Config;

import it.unimi.dsi.fastutil.longs.LongArrayList;
import org.joml.Vector3f;

/**
 * The custom destruction algorithm used by every heavy weapon in the mod.
 *
 * Unlike vanilla explosions (ray-based, tiny), this:
 *  - supports spherical, cylindrical and cuboid destruction zones,
 *  - digs craters (asymmetric top/bottom profile),
 *  - respects the block filter, world height and the configured block cap,
 *  - only collects packed block positions (longs) — never live block state —
 *    and hands them to the DestructionManager for per-tick budgeted removal,
 *  - damages and launches entities with distance falloff,
 *  - plays dramatic, density-scaled visuals via server particles.
 *
 * All work happens server-side; clients see it through vanilla particle/sound
 * sync, so no custom networking is required.
 */
public final class CustomExplosion {

    /** Destruction zone shapes. */
    public enum Shape {
        /** Classic bomb crater: deep bowl, shallow rim. */
        SPHERE,
        /** Vertical cylinder — the orbital/annihilator "bore through everything" shape. */
        CYLINDER,
        /** Rectangular prism of destruction. */
        CUBOID
    }

    private CustomExplosion() {
    }

    /** Parses the config string, falling back to SPHERE. */
    public static Shape shapeFromConfig() {
        String s = Config.BOMB_SHAPE.get() == null ? "sphere" : Config.BOMB_SHAPE.get().toLowerCase();
        switch (s) {
            case "cylinder":
            case "cylindrical":
                return Shape.CYLINDER;
            case "cuboid":
            case "rectangle":
            case "rectangular":
                return Shape.CUBOID;
            default:
                return Shape.SPHERE;
        }
    }

    /**
     * Detonates a fully-configured explosion.
     *
     * @param level            server world (authoritative)
     * @param center           explosion center
     * @param requestedRadius  weapon radius in blocks (global multiplier and the
     *                         hard max radius cap are applied inside)
     * @param shape            destruction zone shape
     * @param fire             whether to leave fire on the crater rim
     * @param crater           whether to dig extra depth below the center
     * @param damage           base entity damage at the center (falloff with distance)
     * @param knockback        base launch strength for entities
     * @param maxBlocksOverride per-strike block cap; 0 = use the global cap
     * @param source           optional damage source entity (nullable)
     */
    public static void explode(ServerLevel level, Vec3 center, double requestedRadius, Shape shape,
                               boolean fire, boolean crater, float damage, double knockback,
                               int maxBlocksOverride, @Nullable Entity source) {
        // Apply the global multiplier, then clamp to the hard safety cap.
        double radius = Math.max(1.0, requestedRadius * Config.globalMultiplier());
        radius = Math.min(radius, Config.maxExplosionRadius());

        boolean craters = crater && Config.cratersEnabled();
        int maxBlocks = maxBlocksOverride > 0
                ? Math.min(maxBlocksOverride, Config.maxBlocksPerStrike())
                : Config.maxBlocksPerStrike();

        long[] positions = collectPositions(level, center, radius, shape, craters, maxBlocks);

        // Queue the terrain destruction; place fire on the rim when the batch finishes.
        float dropChance = (float) Config.dropChance();
        boolean wantFire = fire && Config.FIRE_ENABLED.get();
        DestructionManager.enqueue(level, positions, dropChance,
                wantFire ? () -> placeFireRim(level, center, radius) : null);

        // Entity damage + launch, applied immediately (authoritative on the server).
        damageEntities(level, center, radius, damage, knockback, source);

        // Shared dramatic visuals.
        visuals(level, center, radius);
    }

    /**
     * Collects every destroyable block position in the destruction zone,
     * packed into longs, capped at maxBlocks. Terrain is sampled lazily via
     * getBlockState only for positions that pass the geometric test, so the
     * filter runs cheap even for radius-32 zones.
     */
    private static long[] collectPositions(ServerLevel level, Vec3 center, double radius,
                                           Shape shape, boolean crater, int maxBlocks) {
        LongArrayList list = new LongArrayList(Math.min(maxBlocks, 1 << 16));

        // Vertical extents per shape: craters dig below, blasts vent above.
        double top;
        double bottom;
        switch (shape) {
            case CYLINDER -> {
                top = center.y + radius * 1.2;
                bottom = center.y - (crater ? radius * 0.55 : radius * 0.25);
            }
            case CUBOID -> {
                top = center.y + radius * 0.8;
                bottom = center.y - (crater ? radius * 0.6 : radius * 0.3);
            }
            default -> { // SPHERE handled per-block below
                top = center.y + radius;
                bottom = center.y - radius;
            }
        }

        // Clamp to world height so we never iterate outside the world.
        int minY = Math.max(level.getMinBuildHeight(), Mth.floor(bottom) - 1);
        int maxY = Math.min(level.getMaxBuildHeight() - 1, Mth.ceil(top) + 1);

        int cx = Mth.floor(center.x);
        int cz = Mth.floor(center.z);
        int hx = Mth.ceil(radius);
        int hz = Mth.ceil(radius);

        BlockPos min = new BlockPos(cx - hx, minY, cz - hz);
        BlockPos max = new BlockPos(cx + hx, maxY, cz + hz);

        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            double dx = pos.getX() + 0.5 - center.x;
            double dy = pos.getY() + 0.5 - center.y;
            double dz = pos.getZ() + 0.5 - center.z;

            // Jagged edge: each block independently at 88%-100% of the radius,
            // which produces natural-looking crater rims instead of perfect spheres.
            double edge = radius * (0.88 + level.random.nextDouble() * 0.12);

            boolean inside;
            switch (shape) {
                case SPHERE -> {
                    // Crater profile: full radius below the center, tapering to
                    // 55% at the top — a bowl instead of a ball. Above the
                    // center the vertical dimension is compressed (verticalScale
                    // < 1), which makes the upper rim shallow while the pit digs deep.
                    double verticalScale = dy > 0
                            ? Mth.clamp(1.0 - 0.45 * (dy / Math.max(radius, 0.001)), 0.55, 1.0)
                            : 1.0;
                    double scaledDy = dy / verticalScale;
                    inside = (dx * dx + scaledDy * scaledDy + dz * dz) <= edge * edge;
                }
                case CYLINDER -> {
                    double horiz = dx * dx + dz * dz;
                    inside = horiz <= edge * edge
                            && pos.getY() >= center.y - (crater ? radius * 0.55 : radius * 0.25)
                            && pos.getY() <= center.y + radius * 1.2;
                }
                default -> { // CUBOID
                    inside = Math.abs(dx) <= edge
                            && Math.abs(dz) <= edge
                            && pos.getY() >= center.y - (crater ? radius * 0.6 : radius * 0.3)
                            && pos.getY() <= center.y + radius * 0.8;
                }
            }
            if (!inside) {
                continue;
            }

            // Skip unloaded chunks entirely (never force-load terrain).
            if (!level.hasChunkAt(pos)) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            if (state.isAir() || !BlockFilter.canDestroy(level, pos, state)) {
                continue;
            }

            list.add(pos.asLong());
            if (list.size() >= maxBlocks) {
                break; // hard cap reached — stop collecting
            }
        }
        return list.toLongArray();
    }

    /**
     * Damages and launches every entity in range with linear falloff from
     * the center. Sets hurtMarked so velocity changes sync to clients.
     */
    private static void damageEntities(ServerLevel level, Vec3 center, double radius,
                                       float damage, double knockback, @Nullable Entity source) {
        double reach = radius * 1.15 + 1.5;
        AABB box = new AABB(
                center.x - reach, center.y - reach, center.z - reach,
                center.x + reach, center.y + reach, center.z + reach);

        DamageSource damageSource = level.damageSources().explosion(source);
        for (Entity entity : level.getEntities(null, box)) {
            if (entity.isInvulnerableTo(damageSource)) {
                continue;
            }
            double dist = entity.position().distanceTo(center);
            if (dist > reach) {
                continue;
            }
            double falloff = 1.0 - dist / reach;
            float dmg = Math.max(6.0F, (float) (damage * falloff));
            entity.hurt(damageSource, dmg);

            Vec3 push = entity.position().subtract(center);
            if (push.lengthSqr() < 1.0E-4) {
                push = new Vec3(0, 1, 0);
            }
            push = push.normalize().scale(knockback * falloff + 0.15);
            entity.setDeltaMovement(entity.getDeltaMovement().add(push.x, push.y + 0.4 * falloff, push.z));
            entity.hurtMarked = true; // force velocity sync to the owning client
        }
    }

    /** Server-side dramatic visuals: flash, fireball, shockwave rings, smoke column. */
    private static void visuals(ServerLevel level, Vec3 center, double radius) {
        float density = (float) Config.particleDensity();
        float vol = (float) Config.soundVolume();

        // Sounds: big booms get thunder layered underneath.
        level.playSound(null, center.x, center.y, center.z,
                SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 4.0F * vol, radius >= 10 ? 0.7F : 1.0F);
        if (radius >= 12) {
            level.playSound(null, center.x, center.y, center.z,
                    SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.WEATHER, 2.0F * vol, 0.8F);
        }

        // Initial fireball + flash.
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, center.x, center.y, center.z,
                Math.max(1, (int) (radius / 8) + 1), radius * 0.08, radius * 0.08, radius * 0.08, 0);
        level.sendParticles(ParticleTypes.EXPLOSION, center.x, center.y, center.z,
                DestructionManager.count((int) (radius * 1.5)), radius / 4, radius / 4, radius / 4, 0.3);
        level.sendParticles(ParticleTypes.FLASH, center.x, center.y + 1, center.z, 1, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.FLAME, center.x, center.y + 0.5, center.z,
                DestructionManager.count((int) (radius * 1.2)), radius * 0.25, 0.5, radius * 0.25, 0.35);
        if (radius >= 8) {
            level.sendParticles(ParticleTypes.LAVA, center.x, center.y + 1, center.z,
                    DestructionManager.count(8), radius * 0.2, 0.5, radius * 0.2, 0);
        }

        // Expanding shockwave rings over the next ticks.
        int rings = 6;
        for (int i = 1; i <= rings; i++) {
            final double r = radius * i / rings;
            final int pts = DestructionManager.count(Math.max(16, (int) (radius * 2)));
            DestructionManager.schedule(i, () -> {
                DestructionManager.ring(level, center, r, center.y + 1.0, pts,
                        i % 2 == 0 ? ParticleTypes.CLOUD : ParticleTypes.FLAME, 0.4);
                if (i % 2 == 0) {
                    DestructionManager.ring(level, center, r, center.y + 1.0, pts,
                            new DustParticleOptions(new Vector3f(1.0F, 0.5F, 0.1F), 2.0F), 0);
                }
            });
        }

        // Lingering smoke column.
        int smokeTicks = (int) Math.min(200, 20 + radius * 2);
        for (int t = 0; t < smokeTicks; t += 4) {
            DestructionManager.schedule(t, () -> {
                level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, center.x, center.y + 1.5, center.z,
                        DestructionManager.count(2), radius * 0.12, 1.2, radius * 0.12, 0.02);
                level.sendParticles(ParticleTypes.LARGE_SMOKE, center.x, center.y + 0.5, center.z,
                        DestructionManager.count(2), radius * 0.1, 0.6, radius * 0.1, 0.05);
            });
        }
    }

    /**
     * Scatters fire blocks on the crater rim after the terrain batch finished.
     * Fire placement uses setBlock; vanilla fire validates itself and
     * extinguishes when it cannot survive, so no extra checks are needed.
     */
    private static void placeFireRim(ServerLevel level, Vec3 center, double radius) {
        int count = Config.fireBlocks();
        for (int i = 0; i < count; i++) {
            double angle = level.random.nextDouble() * Math.PI * 2.0;
            double dist = radius * (0.45 + level.random.nextDouble() * 0.55);
            int x = Mth.floor(center.x + Math.cos(angle) * dist);
            int z = Mth.floor(center.z + Math.sin(angle) * dist);

            // Find the first free spot above ground near the crater rim.
            for (int yOff = 4; yOff >= -4; yOff--) {
                BlockPos pos = new BlockPos(x, Mth.floor(center.y) + yOff, z);
                BlockPos below = pos.below();
                BlockState airState = level.getBlockState(pos);
                BlockState belowState = level.getBlockState(below);
                if (airState.isAir() && !belowState.isAir()
                        && belowState.isFaceSturdy(level, below, net.minecraft.core.Direction.UP)
                        && level.random.nextFloat() < 0.6F) {
                    level.setBlock(pos, Blocks.FIRE.defaultBlockState(), 3);
                    break;
                }
            }
        }
    }
}
