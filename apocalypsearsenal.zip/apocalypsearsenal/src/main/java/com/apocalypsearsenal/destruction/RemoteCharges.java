package com.apocalypsearsenal.destruction;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

import com.apocalypsearsenal.Config;
import com.apocalypsearsenal.registry.ModBlocks;

/**
 * Tracks placed remote charges per (dimension, channel) so the remote
 * detonator can trigger them.
 *
 * Safety properties:
 *  - all bookkeeping happens on the server thread,
 *  - triggering is capped by remoteMaxChargesPerTrigger,
 *  - charges removed by explosions simply unregister themselves (no chain
 *    reaction: one charge's blast can never re-trigger another charge),
 *  - the whole map is cleared when the server stops.
 */
public final class RemoteCharges {

    private static final Map<ResourceKey<Level>, Map<Integer, Set<BlockPos>>> CHARGES = new HashMap<>();

    private RemoteCharges() {
    }

    public static synchronized void register(ServerLevel level, BlockPos pos, int channel) {
        CHARGES.computeIfAbsent(level.dimension(), k -> new HashMap<>())
                .computeIfAbsent(channel, k -> new HashSet<>())
                .add(pos.immutable());
    }

    public static synchronized void unregister(Level level, BlockPos pos) {
        Map<Integer, Set<BlockPos>> channels = CHARGES.get(level.dimension());
        if (channels == null) {
            return;
        }
        for (Set<BlockPos> set : channels.values()) {
            set.remove(pos);
        }
    }

    public static synchronized void clear() {
        CHARGES.clear();
    }

    /**
     * Detonates all charges on the given channel within the configured range
     * of the player. Explosions are staggered a few ticks apart so a large
     * linked network never detonates in a single tick.
     *
     * @return the number of charges actually triggered
     */
    public static synchronized int trigger(ServerLevel level, Player user, int channel) {
        Map<Integer, Set<BlockPos>> channels = CHARGES.get(level.dimension());
        if (channels == null) {
            return 0;
        }
        Set<BlockPos> candidates = channels.get(channel);
        if (candidates == null || candidates.isEmpty()) {
            return 0;
        }

        double rangeSq = Config.remoteTriggerRange() * Config.remoteTriggerRange();
        int cap = Config.remoteMaxChargesPerTrigger();
        List<BlockPos> toDetonate = new ArrayList<>();

        for (BlockPos pos : candidates) {
            if (toDetonate.size() >= cap) {
                break;
            }
            // Skip stale entries (block already gone or replaced).
            if (level.getBlockState(pos).getBlock() != ModBlocks.REMOTE_CHARGE.get()) {
                continue;
            }
            if (pos.distToCenterSqr(user.position()) > rangeSq) {
                continue;
            }
            toDetonate.add(pos.immutable());
        }

        int index = 0;
        for (BlockPos pos : toDetonate) {
            // Re-verify then remove the block; its onRemove hook unregisters it,
            // which also guarantees a charge can never be triggered twice.
            if (level.getBlockState(pos).getBlock() != ModBlocks.REMOTE_CHARGE.get()) {
                continue;
            }
            level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
            final Vec3 center = Vec3.atCenterOf(pos);
            // Stagger: 2 ticks between charge blasts to spread server load.
            final int delay = (index++) * 2;
            DestructionManager.schedule(delay, () ->
                    CustomExplosion.explode(level, center, Config.remoteChargeRadius(),
                            CustomExplosion.shapeFromConfig(), true, false, 60.0F, 2.0, 0, null));
        }
        return index;
    }
}
