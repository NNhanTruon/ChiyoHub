package com.apocalypsearsenal.entity;

import com.apocalypsearsenal.Config;
import com.apocalypsearsenal.destruction.CustomExplosion;
import com.apocalypsearsenal.registry.ModEntities;
import com.apocalypsearsenal.registry.ModItems;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * The Cluster Bomb: on detonation it bursts into a configurable number of
 * secondary charges which scatter and each explode on their own short fuse.
 *
 * Anti-recursion: the secondary charges are a different entity class
 * (ClusterChargeEntity) that never spawns more of itself, so the chain is
 * exactly one level deep by construction.
 */
public class ClusterBombEntity extends AbstractBombEntity {

    public ClusterBombEntity(EntityType<? extends ClusterBombEntity> type, Level level) {
        super(type, level);
        this.fuse = Config.fusionFuse();
    }

    @Override
    public int defaultFuse() {
        return Config.fusionFuse();
    }

    @Override
    public ItemStack getItem() {
        return new ItemStack(ModItems.CLUSTER_BOMB.get());
    }

    @Override
    protected void detonate() {
        ServerLevel level = serverLevel();
        Vec3 center = center();

        // Split into secondary charges.
        int count = Config.clusterCount();
        double spread = Config.clusterSpread();
        for (int i = 0; i < count; i++) {
            ClusterChargeEntity charge = ModEntities.CLUSTER_CHARGE.get().create(level);
            if (charge == null) {
                continue;
            }
            charge.setPos(this.getX(), this.getY() + 0.3D, this.getZ());
            double angle = level.random.nextDouble() * Math.PI * 2.0D;
            double horizontal = 0.35D + level.random.nextDouble() * 0.6D;
            double lift = 0.3D + level.random.nextDouble() * 0.5D;
            double factor = spread / 6.0D; // spread scales the throw strength
            charge.setDeltaMovement(
                    Math.cos(angle) * horizontal * factor,
                    lift,
                    Math.sin(angle) * horizontal * factor);
            charge.setFuse(Config.clusterChargeFuse() / 2
                    + level.random.nextInt(Config.clusterChargeFuse()));
            level.addFreshEntity(charge);
        }

        level.playSound(null, this.getX(), this.getY(), this.getZ(),
                SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 3.0F, 1.2F);

        // Small central pop for feedback.
        CustomExplosion.explode(level, center, 3.0D, CustomExplosion.Shape.SPHERE,
                false, false, 20.0F, 1.5, 256, null);
    }
}
