package com.apocalypsearsenal.entity;

import com.apocalypsearsenal.Config;
import com.apocalypsearsenal.destruction.CustomExplosion;
import com.apocalypsearsenal.registry.ModItems;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * A single secondary charge scattered by a Cluster Bomb. Never splits
 * again — the cluster chain is exactly one level deep.
 */
public class ClusterChargeEntity extends AbstractBombEntity {

    public ClusterChargeEntity(EntityType<? extends ClusterChargeEntity> type, Level level) {
        super(type, level);
        this.fuse = Config.clusterChargeFuse();
    }

    @Override
    public int defaultFuse() {
        return Config.clusterChargeFuse();
    }

    @Override
    public ItemStack getItem() {
        return new ItemStack(ModItems.CLUSTER_BOMB.get());
    }

    @Override
    protected void detonate() {
        CustomExplosion.explode(serverLevel(), center(), Config.clusterSecondaryRadius(),
                CustomExplosion.Shape.SPHERE,
                Config.FIRE_ENABLED.get(), false,
                45.0F, 1.6, 0, null);
    }
}
