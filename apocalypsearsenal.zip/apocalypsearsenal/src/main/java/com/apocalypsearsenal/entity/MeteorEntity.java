package com.apocalypsearsenal.entity;

import java.util.List;

import com.apocalypsearsenal.Config;
import com.apocalypsearsenal.destruction.CustomExplosion;
import com.apocalypsearsenal.destruction.DestructionManager;
import com.apocalypsearsenal.registry.ModItems;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import org.joml.Vector3f;

/**
 * The falling meteor: descends from the sky at high speed with a burning
 * trail and detonates on the first thing it touches — terrain, entity,
 * or the void floor.
 */
public class MeteorEntity extends AbstractBombEntity {

    private static final double MAX_DESCENT_SPEED = 3.2D;
    private static final double DESCENT_ACCELERATION = 0.2D;

    public MeteorEntity(EntityType<? extends MeteorEntity> type, Level level) {
        super(type, level);
        this.fuse = 72000; // no fuse: impact-triggered
    }

    @Override
    public int defaultFuse() {
        return 72000;
    }

    @Override
    public ItemStack getItem() {
        return new ItemStack(ModItems.METEOR_CORE.get());
    }

    @Override
    protected void tickPhysics() {
        // Constant, heavy downward acceleration capped at terminal velocity —
        // the meteor does not arc, it plummets.
        double speed = Math.max(this.getDeltaMovement().y - DESCENT_ACCELERATION, -MAX_DESCENT_SPEED);
        this.setDeltaMovement(0.0D, speed, 0.0D);
        this.move(net.minecraft.world.entity.MoverType.SELF, this.getDeltaMovement());
    }

    @Override
    protected void tickLogic() {
        ServerLevel level = serverLevel();

        // Burning trail.
        level.sendParticles(ParticleTypes.FLAME, this.getX(), this.getY() + 0.5D, this.getZ(),
                DestructionManager.count(6), 0.3D, 0.3D, 0.3D, 0.05D);
        level.sendParticles(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 1.0D, this.getZ(),
                DestructionManager.count(4), 0.4D, 0.2D, 0.4D, 0.02D);
        level.sendParticles(ParticleTypes.LAVA, this.getX(), this.getY(), this.getZ(),
                DestructionManager.count(1), 0.2D, 0.2D, 0.2D, 0.0D);
        level.sendParticles(ParticleTypes.FALLING_LAVA, this.getX(), this.getY() - 0.5, this.getZ(),
                DestructionManager.count(2), 0.3D, 0.1D, 0.3D, 0.0D);

        // Impact on terrain.
        if (this.onGround || this.horizontalCollision || this.verticalCollision) {
            impact(level);
            return;
        }
        // Impact on entities.
        List<Entity> hit = level.getEntities(this, this.getBoundingBox());
        if (!hit.isEmpty()) {
            impact(level);
            return;
        }
        // Fell out of the world.
        if (this.getY() < level.getMinBuildHeight() - 10.0D) {
            this.discard();
        }
    }

    @Override
    protected void clientTrail() {
        // Extra client-side ember sparks around the falling rock.
        this.level.addParticle(ParticleTypes.FLAME,
                this.getX() + (this.level.random.nextDouble() - 0.5D) * 0.8D,
                this.getY() + this.level.random.nextDouble() * 0.8D,
                this.getZ() + (this.level.random.nextDouble() - 0.5D) * 0.8D,
                0.0D, 0.05D, 0.0D);
    }

    private void impact(ServerLevel level) {
        Vec3 center = center();

        // Entry visuals: white-hot flash plus a rising fire plume.
        level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, center.x, center.y, center.z, 2, 0.5, 0.5, 0.5, 0);
        level.sendParticles(ParticleTypes.FLASH, center.x, center.y + 1.0D, center.z, 2, 0, 0, 0, 0);
        level.sendParticles(ParticleTypes.FLAME, center.x, center.y + 1.0D, center.z,
                DestructionManager.count(30), 1.5D, 1.0D, 1.5D, 0.3D);
        level.sendParticles(ParticleTypes.FALLING_LAVA, center.x, center.y + 2.0D, center.z,
                DestructionManager.count(10), 2.0D, 1.0D, 2.0D, 0.0D);
        DestructionManager.ring(level, center, 3.0D, center.y + 0.5D,
                DestructionManager.count(24),
                new DustParticleOptions(new Vector3f(1.0F, 0.4F, 0.05F), 3.0F), 0.0D);

        level.playSound(null, center.x, center.y, center.z,
                SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.WEATHER, 4.0F, 0.7F);

        // Big crater-forming explosion with fire.
        CustomExplosion.explode(level, center, Config.meteorRadius(),
                CustomExplosion.shapeFromConfig(),
                Config.FIRE_ENABLED.get(), true,
                (float) (Config.meteorRadius() * 7.0), 3.0, 0, null);

        this.discard();
    }

    @Override
    protected void detonate() {
        // Unused: the meteor detonates on impact instead of on a fuse.
    }
}
