package com.apocalypsearsenal.entity;

import java.util.List;

import com.apocalypsearsenal.Config;
import com.apocalypsearsenal.destruction.CustomExplosion;
import com.apocalypsearsenal.destruction.DestructionManager;
import com.apocalypsearsenal.registry.ModItems;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import org.joml.Vector3f;

/**
 * The Thermobaric Bomb: an exceptionally powerful localized blast with a
 * clear warning phase and a few delayed secondary detonations inside the
 * blast zone.
 *
 * The secondaries are plain explosions (they schedule nothing further),
 * so the reaction chain is strictly finite.
 */
public class ThermobaricBombEntity extends AbstractBombEntity {

    private boolean warned;

    public ThermobaricBombEntity(EntityType<? extends ThermobaricBombEntity> type, Level level) {
        super(type, level);
        this.fuse = Config.thermobaricFuse();
    }

    @Override
    public int defaultFuse() {
        return Config.thermobaricFuse();
    }

    @Override
    public ItemStack getItem() {
        return new ItemStack(ModItems.THERMOBARIC_BOMB.get());
    }

    @Override
    protected void onFuseTick() {
        super.onFuseTick();

        // Intensifying warning during the final three seconds:
        // siren-like beeps plus an expanding red pressure ring.
        if (this.fuse <= 60 && this.fuse % 10 == 0) {
            ServerLevel level = serverLevel();
            level.playSound(null, this.getX(), this.getY(), this.getZ(),
                    SoundEvents.BEACON_DEACTIVATE, SoundSource.BLOCKS, 2.0F, 0.5F);
            double progress = 1.0 - this.fuse / 60.0;
            DestructionManager.ring(level, center(), 2.0 + progress * 8.0, this.getY() + 0.3,
                    DestructionManager.count(32),
                    new DustParticleOptions(new Vector3f(1.0F, 0.2F, 0.05F), 2.0F), 0.0D);
        }

        // One clear warning message for every player in the danger zone.
        if (!this.warned && this.fuse <= 80) {
            this.warned = true;
            ServerLevel level = serverLevel();
            List<Player> nearby = level.getEntitiesOfClass(Player.class,
                    this.getBoundingBox().inflate(48.0D));
            for (Player player : nearby) {
                player.displayClientMessage(
                        Component.translatable("message.apocalypsearsenal.thermobaric_warning"), true);
            }
            level.playSound(null, this.getX(), this.getY(), this.getZ(),
                    SoundEvents.ENDER_DRAGON_GROWL, SoundSource.HOSTILE, 2.0F, 0.7F);
        }
    }

    @Override
    protected void detonate() {
        ServerLevel level = serverLevel();
        Vec3 center = center();
        double radius = Config.thermobaricRadius();

        // Main fuel-air blast.
        CustomExplosion.explode(level, center, radius,
                CustomExplosion.shapeFromConfig(),
                Config.FIRE_ENABLED.get(), true,
                (float) (radius * 7.0), 3.0, 0, null);

        // Delayed secondary detonations scattered inside the blast zone.
        int secondaries = Config.thermobaricSecondaries();
        for (int i = 0; i < secondaries; i++) {
            final Vec3 offset = new Vec3(
                    (level.random.nextDouble() - 0.5D) * radius * 0.8D,
                    0.5D,
                    (level.random.nextDouble() - 0.5D) * radius * 0.8D);
            final Vec3 pos = center.add(offset);
            final int delay = 8 + i * 5 + level.random.nextInt(6);
            DestructionManager.schedule(delay, () ->
                    CustomExplosion.explode(level, pos, Config.thermobaricSecondaryRadius(),
                            CustomExplosion.Shape.SPHERE,
                            Config.FIRE_ENABLED.get(), false,
                            40.0F, 1.5, 0, null));
        }
    }
}
