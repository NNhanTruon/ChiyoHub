package com.apocalypsearsenal.entity;

import com.apocalypsearsenal.Config;
import com.apocalypsearsenal.registry.ModEntities;
import com.apocalypsearsenal.registry.ModItems;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import org.joml.Vector3f;

/**
 * Meteor Strike Beacon: a throwable marker. When it lands it plants itself,
 * shows a target marker + warning beam for a configurable countdown, then
 * calls down a meteor from the sky.
 */
public class MeteorBeaconEntity extends AbstractBombEntity {

    /** -1 = still airborne / inert. >= 0 = countdown running. */
    private int countdown = -1;

    public MeteorBeaconEntity(EntityType<? extends MeteorBeaconEntity> type, Level level) {
        super(type, level);
        this.fuse = 72000; // base fuse machinery unused; the beacon has its own countdown
    }

    @Override
    public int defaultFuse() {
        return 72000;
    }

    @Override
    public ItemStack getItem() {
        return new ItemStack(ModItems.METEOR_BEACON.get());
    }

    @Override
    protected void tickLogic() {
        ServerLevel level = serverLevel();

        // Phase 1: fly until the beacon lands.
        if (this.countdown < 0) {
            if (this.onGround) {
                this.countdown = Config.meteorCountdown();
                this.setDeltaMovement(Vec3.ZERO);
                level.playSound(null, this.getX(), this.getY(), this.getZ(),
                        SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 2.0F, 0.4F);
                level.playSound(null, this.getX(), this.getY(), this.getZ(),
                        SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 1.5F, 0.6F);
            } else if (this.getY() < level.getMinBuildHeight() - 20.0D) {
                this.discard(); // fell out of the world
            }
            return;
        }

        // Phase 2: countdown with target marker and warning beam.
        this.countdown--;
        if (this.countdown % 5 == 0) {
            // Ground marker: flame + red dust ring pulsing outward.
            double progress = 1.0 - (double) this.countdown / Math.max(1, Config.meteorCountdown());
            DestructionManager.ring(level, center(), 1.5 + progress * 4.0, this.getY() + 0.2,
                    DestructionManager.count(20), ParticleTypes.FLAME, 0.0D);
            DestructionManager.ring(level, center(), 1.5 + progress * 4.0, this.getY() + 0.4,
                    DestructionManager.count(20),
                    new DustParticleOptions(new Vector3f(1.0F, 0.3F, 0.05F), 2.0F), 0.0D);

            // Vertical warning beam into the sky.
            double beamTop = Math.min(this.getY() + 90.0D, level.getMaxBuildHeight() - 2.0D);
            for (double y = this.getY() + 2.0D; y < beamTop; y += 3.0D) {
                level.sendParticles(ParticleTypes.END_ROD, this.getX(), y, this.getZ(), 0, 0, 0, 0, 0);
            }
        }
        if (this.countdown % 15 == 0) {
            level.playSound(null, this.getX(), this.getY(), this.getZ(),
                    SoundEvents.BEACON_DEACTIVATE, SoundSource.BLOCKS, 1.5F, 0.6F);
        }

        // Phase 3: launch the meteor.
        if (this.countdown <= 0) {
            MeteorEntity meteor = ModEntities.METEOR.get().create(level);
            if (meteor != null) {
                double spawnY = Math.min(
                        this.getY() + Config.meteorSpawnHeight(),
                        level.getMaxBuildHeight() - 10.0D);
                meteor.setPos(this.getX(), Math.max(spawnY, this.getY() + 30.0D), this.getZ());
                meteor.setDeltaMovement(0.0D, -2.4D, 0.0D);
                level.addFreshEntity(meteor);
            }
            level.playSound(null, this.getX(), this.getY(), this.getZ(),
                    SoundEvents.ENDER_DRAGON_GROWL, SoundSource.HOSTILE, 4.0F, 0.6F);
            this.discard();
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Countdown", this.countdown);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.countdown = tag.contains("Countdown") ? Mth.clamp(tag.getInt("Countdown"), -1, 72000) : -1;
    }

    @Override
    protected void detonate() {
        // The beacon itself never explodes; the meteor does the talking.
    }
}
