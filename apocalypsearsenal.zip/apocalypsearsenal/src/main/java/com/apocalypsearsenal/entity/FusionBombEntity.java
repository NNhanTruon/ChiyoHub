package com.apocalypsearsenal.entity;

import com.apocalypsearsenal.Config;
import com.apocalypsearsenal.destruction.CustomExplosion;
import com.apocalypsearsenal.registry.ModItems;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * The Fusion Bomb: a massive single detonation with a deep crater.
 */
public class FusionBombEntity extends AbstractBombEntity {

    public FusionBombEntity(EntityType<? extends FusionBombEntity> type, Level level) {
        super(type, level);
        this.fuse = Config.fusionFuse();
    }

    @Override
    public int defaultFuse() {
        return Config.fusionFuse();
    }

    @Override
    public ItemStack getItem() {
        return new ItemStack(ModItems.FUSION_BOMB.get());
    }

    @Override
    protected void detonate() {
        double radius = Config.fusionRadius();
        CustomExplosion.explode(serverLevel(), center(), radius,
                CustomExplosion.shapeFromConfig(),
                Config.FIRE_ENABLED.get(), true,
                (float) (radius * 6.0), 2.5, 0, null);
    }
}
