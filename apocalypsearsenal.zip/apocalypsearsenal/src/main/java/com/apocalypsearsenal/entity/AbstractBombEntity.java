package com.apocalypsearsenal.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ItemSupplier;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Shared base for all thrown/placed explosives and devices in the mod.
 *
 * Physics: simple ballistic integration (gravity, block collision via
 * {@link Entity#move}, ground friction) — no vanilla projectile machinery.
 *
 * Fuse: pure server-side countdown; rendering uses only the vanilla
 * ThrownItemRenderer, so no synched fuse data is needed.
 */
public abstract class AbstractBombEntity extends Entity implements ItemSupplier {

    protected int fuse = 80;

    public AbstractBombEntity(EntityType<?> type, Level level) {
        super(type, level);
    }

    public AbstractBombEntity(EntityType<?> type, double x, double y, double z, Level level) {
        this(type, level);
        this.setPos(x, y, z);
    }

    /** @return the fuse length (in ticks) this bomb spawns with. */
    public abstract int defaultFuse();

    /** Detonation behavior when the fuse (or impact condition) is met. */
    protected abstract void detonate();

    public void setFuse(int fuse) {
        this.fuse = fuse;
    }

    public int getFuse() {
        return this.fuse;
    }

    /**
     * Launches the bomb along a direction with speed and inaccuracy
     * (a hand-rolled replacement for Projectile#shoot).
     */
    public void shoot(Vec3 direction, float speed, float spread) {
        Vec3 motion = direction.scale(speed);
        if (spread > 0.0F) {
            double rx = (this.level.random.nextDouble() - 0.5D) * spread;
            double ry = (this.level.random.nextDouble() - 0.5D) * spread + 0.1D;
            double rz = (this.level.random.nextDouble() - 0.5D) * spread;
            motion = motion.add(rx, ry, rz);
        }
        this.setDeltaMovement(motion);
    }

    @Override
    public void tick() {
        // Entity#tick -> baseTick (fire, portal, drowning checks ...).
        super.tick();

        this.tickPhysics();

        if (!this.level.isClientSide) {
            this.tickLogic();
        } else {
            this.clientTrail();
        }
    }

    /**
     * Standard bomb physics: gravity, collision, ground friction.
     * The meteor overrides this with its fast, unstoppable descent.
     */
    protected void tickPhysics() {
        this.setDeltaMovement(this.getDeltaMovement().add(0.0D, -0.04D, 0.0D));
        this.move(MoverType.SELF, this.getDeltaMovement());
        if (this.onGround) {
            Vec3 dm = this.getDeltaMovement();
            this.setDeltaMovement(dm.x * 0.5D, dm.y * 0.4D, dm.z * 0.5D);
        }
    }

    /** Client-side smoke trail while the bomb is airborne. */
    protected void clientTrail() {
        if (!this.onGround) {
            this.level.addParticle(ParticleTypes.SMOKE,
                    this.getX(), this.getY() + 0.2D, this.getZ(),
                    0.0D, 0.02D, 0.0D);
        }
    }

    /**
     * Server logic: fuse countdown -> detonation.
     * The beacon and meteor override this with their own state machines.
     */
    protected void tickLogic() {
        if (this.fuse <= 0) {
            return;
        }
        this.fuse--;
        this.onFuseTick();
        if (this.fuse <= 0) {
            this.detonate();
            this.discard();
        }
    }

    /** Per-tick fuse hook (warning sounds etc.). */
    protected void onFuseTick() {
        // Classic TNT-style fuse hiss once a second.
        if (this.fuse > 0 && this.fuse % 20 == 0) {
            this.level.playSound(null, this.getX(), this.getY(), this.getZ(),
                    SoundEvents.TNT_PRIMER, SoundSource.BLOCKS, 1.0F, 1.0F);
        }
    }

    /** Helper for subclasses: casts to ServerLevel (safe — only called server-side). */
    protected ServerLevel serverLevel() {
        return (ServerLevel) this.level;
    }

    /** Helper for subclasses: detonation position. */
    protected Vec3 center() {
        return this.position();
    }

    // ------------------------------------------------------------------
    // Boilerplate
    // ------------------------------------------------------------------

    @Override
    protected void defineSynchedData() {
        // No synched data needed: rendering is item-based, fuse is server-only.
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Fuse", this.fuse);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.fuse = Mth.clamp(tag.getInt("Fuse"), 0, 72000);
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean isNoGravity() {
        return false; // gravity is applied manually in tickPhysics
    }

    /** Item shown by the ThrownItemRenderer. */
    @Override
    public abstract ItemStack getItem();
}
