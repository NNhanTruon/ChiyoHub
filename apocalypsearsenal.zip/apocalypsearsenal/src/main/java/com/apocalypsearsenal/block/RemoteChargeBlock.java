package com.apocalypsearsenal.block;

import javax.annotation.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import com.apocalypsearsenal.destruction.RemoteCharges;

/**
 * Remote Charge: a placeable explosive block with a channel number stored in
 * its block entity. It is triggered only by the Remote Detonator (or being
 * removed, which just unlinks it). Charges destroyed by other explosions
 * simply vanish — a charge blast can never chain-trigger another charge.
 */
public class RemoteChargeBlock extends BaseEntityBlock {

    public RemoteChargeBlock(Properties properties) {
        super(properties);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new RemoteChargeBlockEntity(pos, state);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        // BaseEntityBlock defaults to INVISIBLE; we are a normal cube.
        return RenderShape.MODEL;
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state,
                            @Nullable net.minecraft.world.entity.LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof RemoteChargeBlockEntity charge) {
            // Charges crafted normally are channel 0; an explicit "Channel" tag
            // on the item stack is honored for advanced setups.
            int channel = stack.hasTag() && stack.getTag() != null && stack.getTag().contains("Channel")
                    ? stack.getTag().getInt("Channel") : 0;
            charge.setChannel(Math.max(0, channel));
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        // Unlink from the detonator registry no matter how the block goes away
        // (mined, blasted, pushed). Unregistering twice is harmless.
        if (!level.isClientSide) {
            RemoteCharges.unregister(level, pos);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }
}
