package com.apocalypsearsenal.block;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import com.apocalypsearsenal.destruction.RemoteCharges;
import com.apocalypsearsenal.registry.ModBlocks;

/**
 * Block entity for the remote charge: stores the detonator channel and
 * keeps the server-side charge registry in sync as the chunk loads and
 * unloads.
 */
public class RemoteChargeBlockEntity extends BlockEntity {

    private int channel = 0;

    public RemoteChargeBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlocks.REMOTE_CHARGE_BE.get(), pos, state);
    }

    public int getChannel() {
        return this.channel;
    }

    public void setChannel(int channel) {
        this.channel = channel;
        this.setChanged();
        // Re-register under the (possibly new) channel so it is instantly triggerable.
        if (this.level != null && !this.level.isClientSide) {
            RemoteCharges.register((net.minecraft.server.level.ServerLevel) this.level,
                    this.worldPosition, this.channel);
        }
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (this.level != null && !this.level.isClientSide) {
            RemoteCharges.register((net.minecraft.server.level.ServerLevel) this.level,
                    this.worldPosition, this.channel);
        }
    }

    @Override
    public void setRemoved() {
        if (this.level != null && !this.level.isClientSide) {
            RemoteCharges.unregister(this.level, this.worldPosition);
        }
        super.setRemoved();
    }

    @Override
    public void onChunkUnloaded() {
        if (this.level != null && !this.level.isClientSide) {
            RemoteCharges.unregister(this.level, this.worldPosition);
        }
        super.onChunkUnloaded();
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Channel", this.channel);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.channel = Math.max(0, tag.getInt("Channel"));
    }
}
