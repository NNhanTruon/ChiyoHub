package com.apocalypsearsenal.client;

import com.apocalypsearsenal.ApocalypseArsenal;
import com.apocalypsearsenal.registry.ModEntities;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.client.event.EntityRenderersEvent;

/**
 * Client-only registration: entity renderers.
 *
 * All bomb entities render as their thrown item (they implement ItemSupplier),
 * so no custom renderers or shaders are needed anywhere in this mod.
 */
@Mod.EventBusSubscriber(modid = ApocalypseArsenal.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ClientSetup {

    private ClientSetup() {
    }

    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.FUSION_BOMB.get(), ThrownItemRenderer::new);
        event.registerEntityRenderer(ModEntities.CLUSTER_BOMB.get(), ThrownItemRenderer::new);
        event.registerEntityRenderer(ModEntities.CLUSTER_CHARGE.get(), ThrownItemRenderer::new);
        event.registerEntityRenderer(ModEntities.THERMOBARIC_BOMB.get(), ThrownItemRenderer::new);
        event.registerEntityRenderer(ModEntities.METEOR_BEACON.get(), ThrownItemRenderer::new);
        event.registerEntityRenderer(ModEntities.METEOR.get(), ThrownItemRenderer::new);
    }
}
