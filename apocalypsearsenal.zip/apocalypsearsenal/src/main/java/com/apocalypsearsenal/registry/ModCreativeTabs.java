package com.apocalypsearsenal.registry;

import com.apocalypsearsenal.ApocalypseArsenal;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/**
 * The dedicated Apocalypse Arsenal creative tab, containing every weapon
 * and the remote charge.
 */
public class ModCreativeTabs {

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ApocalypseArsenal.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.apocalypsearsenal"))
                    .icon(() -> new ItemStack(ModItems.ORBITAL_CANNON.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.LASER_RIFLE.get());
                        output.accept(ModItems.MINING_LASER.get());
                        output.accept(ModItems.FUSION_BOMB.get());
                        output.accept(ModItems.CLUSTER_BOMB.get());
                        output.accept(ModItems.THERMOBARIC_BOMB.get());
                        output.accept(ModItems.METEOR_BEACON.get());
                        output.accept(ModItems.ORBITAL_CANNON.get());
                        output.accept(ModItems.PLANETARY_ANNIHILATOR.get());
                        output.accept(ModItems.REMOTE_DETONATOR.get());
                        output.accept(ModItems.REMOTE_CHARGE_ITEM.get());
                        output.accept(ModItems.METEOR_CORE.get());
                    })
                    .build());

    private ModCreativeTabs() {
    }
}
