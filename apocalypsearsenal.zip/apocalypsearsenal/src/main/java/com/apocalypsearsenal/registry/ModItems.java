package com.apocalypsearsenal.registry;

import java.util.function.Supplier;

import com.apocalypsearsenal.ApocalypseArsenal;
import com.apocalypsearsenal.item.BombItem;
import com.apocalypsearsenal.item.LaserRifleItem;
import com.apocalypsearsenal.item.MiningLaserItem;
import com.apocalypsearsenal.item.MeteorBeaconItem;
import com.apocalypsearsenal.item.OrbitalCannonItem;
import com.apocalypsearsenal.item.PlanetaryAnnihilatorItem;
import com.apocalypsearsenal.item.RemoteDetonatorItem;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * All item registrations. Durability values are fixed here (they can only be
 * set at registration time); every behavioral value comes from the config.
 */
public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEM_ITEMS, ApocalypseArsenal.MODID);

    // ------------------------------------------------------------------
    // Weapons
    // ------------------------------------------------------------------

    public static final RegistryObject<Item> LASER_RIFLE = ITEMS.register("laser_rifle",
            () -> new LaserRifleItem(new Item.Properties().durability(512)));

    public static final RegistryObject<Item> MINING_LASER = ITEMS.register("mining_laser",
            () -> new MiningLaserItem(new Item.Properties().durability(1024)));

    public static final RegistryObject<Item> FUSION_BOMB = ITEMS.register("fusion_bomb",
            () -> new BombItem(new Item.Properties().stacksTo(16), ModEntities.FUSION_BOMB));

    public static final RegistryObject<Item> CLUSTER_BOMB = ITEMS.register("cluster_bomb",
            () -> new BombItem(new Item.Properties().stacksTo(8), ModEntities.CLUSTER_BOMB));

    public static final RegistryObject<Item> THERMOBARIC_BOMB = ITEMS.register("thermobaric_bomb",
            () -> new BombItem(new Item.Properties().stacksTo(8), ModEntities.THERMOBARIC_BOMB));

    public static final RegistryObject<Item> METEOR_BEACON = ITEMS.register("meteor_beacon",
            () -> new MeteorBeaconItem(new Item.Properties().stacksTo(4)));

    public static final RegistryObject<Item> ORBITAL_CANNON = ITEMS.register("orbital_cannon",
            () -> new OrbitalCannonItem(new Item.Properties().durability(128)));

    public static final RegistryObject<Item> PLANETARY_ANNIHILATOR = ITEMS.register("planetary_annihilator",
            () -> new PlanetaryAnnihilatorItem(new Item.Properties().durability(64)));

    public static final RegistryObject<Item> REMOTE_DETONATOR = ITEMS.register("remote_detonator",
            () -> new RemoteDetonatorItem(new Item.Properties().stacksTo(1)));

    // ------------------------------------------------------------------
    // Support items
    // ------------------------------------------------------------------

    /** Internal item used to render the falling meteor entity. */
    public static final RegistryObject<Item> METEOR_CORE = ITEMS.register("meteor_core",
            () -> new Item(new Item.Properties()));

    /** Block item for the remote charge. */
    public static final RegistryObject<Item> REMOTE_CHARGE_ITEM = ITEMS.register("remote_charge",
            () -> new BlockItem(ModBlocks.REMOTE_CHARGE.get(), new Item.Properties().stacksTo(16)));

    private ModItems() {
    }

    /** Convenience for tooltips/tests. */
    public static Supplier<Item> iconItem() {
        return ORBITAL_CANNON;
    }
}
