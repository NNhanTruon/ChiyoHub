package com.apocalypsearsenal.registry;

import com.apocalypsearsenal.ApocalypseArsenal;
import com.apocalypsearsenal.entity.AbstractBombEntity;
import com.apocalypsearsenal.entity.ClusterBombEntity;
import com.apocalypsearsenal.entity.ClusterChargeEntity;
import com.apocalypsearsenal.entity.FusionBombEntity;
import com.apocalypsearsenal.entity.MeteorBeaconEntity;
import com.apocalypsearsenal.entity.MeteorEntity;
import com.apocalypsearsenal.entity.ThermobaricBombEntity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Entity registrations. All bombs are MISC entities rendered with the
 * vanilla {@code ThrownItemRenderer} (they implement ItemSupplier), which
 * keeps the mod free of custom renderers while still looking right.
 */
public class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ApocalypseArsenal.MODID);

    public static final RegistryObject<EntityType<FusionBombEntity>> FUSION_BOMB =
            register("fusion_bomb", FusionBombEntity::new, 0.35F, 8, 10);

    public static final RegistryObject<EntityType<ClusterBombEntity>> CLUSTER_BOMB =
            register("cluster_bomb", ClusterBombEntity::new, 0.35F, 8, 10);

    public static final RegistryObject<EntityType<ClusterChargeEntity>> CLUSTER_CHARGE =
            register("cluster_charge", ClusterChargeEntity::new, 0.3F, 8, 10);

    public static final RegistryObject<EntityType<ThermobaricBombEntity>> THERMOBARIC_BOMB =
            register("thermobaric_bomb", ThermobaricBombEntity::new, 0.4F, 8, 10);

    public static final RegistryObject<EntityType<MeteorBeaconEntity>> METEOR_BEACON =
            register("meteor_beacon", MeteorBeaconEntity::new, 0.3F, 8, 10);

    public static final RegistryObject<EntityType<MeteorEntity>> METEOR =
            register("meteor", MeteorEntity::new, 1.0F, 16, 2);

    private static <T extends AbstractBombEntity> RegistryObject<EntityType<T>> register(
            String name, EntityType.EntityFactory<T> factory, float size, int trackingRange, int updateInterval) {
        return ENTITIES.register(name, () -> EntityType.Builder.<T>of(factory, MobCategory.MISC)
                .sized(size, size)
                .fireImmune()
                .clientTrackingRange(trackingRange)
                .updateInterval(updateInterval)
                .build(name));
    }

    private ModEntities() {
    }
}
