package com.apocalypsearsenal.registry;

import com.apocalypsearsenal.ApocalypseArsenal;
import com.apocalypsearsenal.block.RemoteChargeBlock;
import com.apocalypsearsenal.block.RemoteChargeBlockEntity;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Block and block-entity registrations.
 */
public class ModBlocks {

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, ApocalypseArsenal.MODID);

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, ApocalypseArsenal.MODID);

    public static final RegistryObject<Block> REMOTE_CHARGE = BLOCKS.register("remote_charge",
            () -> new RemoteChargeBlock(BlockBehaviour.Properties.of()
                    .strength(0.4F)
                    .sound(SoundType.WOOD)));

    public static final RegistryObject<BlockEntityType<RemoteChargeBlockEntity>> REMOTE_CHARGE_BE =
            BLOCK_ENTITIES.register("remote_charge",
                    () -> BlockEntityType.Builder.of(RemoteChargeBlockEntity::new, REMOTE_CHARGE.get()).build(null));

    private ModBlocks() {
    }
}
