package com.apocalypsearsenal;

import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import com.apocalypsearsenal.destruction.DestructionManager;
import com.apocalypsearsenal.destruction.RemoteCharges;

/**
 * Server-thread event hooks: drives the destruction scheduler every tick
 * and clears all destruction state when the server goes down.
 */
@Mod.EventBusSubscriber(modid = ApocalypseArsenal.MODID)
public final class ServerEvents {

    private ServerEvents() {
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase == TickEvent.Phase.END) {
            DestructionManager.tickAll();
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        DestructionManager.clearAll();
        RemoteCharges.clear();
    }
}
