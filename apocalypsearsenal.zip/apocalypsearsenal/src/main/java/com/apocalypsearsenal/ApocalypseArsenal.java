package com.apocalypsearsenal;

import com.apocalypsearsenal.destruction.BlockFilter;
import com.apocalypsearsenal.registry.ModBlocks;
import com.apocalypsearsenal.registry.ModCreativeTabs;
import com.apocalypsearsenal.registry.ModEntities;
import com.apocalypsearsenal.registry.ModItems;
import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.config.ModConfigEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * Apocalypse Arsenal — a destruction-focused mod for Minecraft 1.20.1 (Forge 47.x).
 *
 * Features: high-energy laser rifle, industrial mining laser, fusion / cluster /
 * thermobaric bombs, meteor strike beacons, the Orbital Strike Cannon,
 * the Planetary Annihilator and a remote detonation system.
 */
@Mod(ApocalypseArsenal.MODID)
public class ApocalypseArsenal {

    public static final String MODID = "apocalypsearsenal";
    public static final Logger LOGGER = LogUtils.getLogger();

    public ApocalypseArsenal() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        // Register all deferred registers on the MOD event bus.
        ModItems.ITEMS.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModBlocks.BLOCK_ENTITIES.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModCreativeTabs.TABS.register(modBus);

        modBus.addListener(this::commonSetup);
        modBus.addListener(this::onConfigLoad);

        // Register the mod configuration (COMMON config, loaded on both sides).
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        LOGGER.info("Apocalypse Arsenal: common setup complete. Stay away from windows.");
    }

    /**
     * Rebuild cached block protection data whenever our config (re)loads.
     */
    private void onConfigLoad(final ModConfigEvent event) {
        if (event.getConfig().getModId().equals(MODID)) {
            BlockFilter.reloadFromConfig();
        }
    }
}
