package com.apocalypsearsenal.item;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import com.apocalypsearsenal.registry.ModEntities;

/**
 * Meteor Strike Beacon: throwable targeting beacon that marks an impact
 * location, counts down, and calls down a meteor. Throwing behavior comes
 * from {@link BombItem}; only the tooltip is specific.
 */
public class MeteorBeaconItem extends BombItem {

    public MeteorBeaconItem(Properties properties) {
        super(properties, ModEntities.METEOR_BEACON);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.apocalypsearsenal.meteor_beacon")
                .withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.translatable("tooltip.apocalypsearsenal.meteor_use")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
