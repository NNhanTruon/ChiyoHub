package com.apocalypsearsenal.item;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

import com.apocalypsearsenal.block.RemoteChargeBlockEntity;
import com.apocalypsearsenal.destruction.RemoteCharges;

/**
 * Remote Detonation System.
 *
 * The detonator stores a channel number:
 *   - Right-click (air): triggers all linked charges on the current channel
 *     within range. Blasts are staggered; the number of charges per click
 *     is capped by config.
 *   - Sneak + right-click (air): cycles the detonator channel (0-9).
 *   - Sneak + right-click a placed charge: links that charge to the
 *     detonator's current channel.
 */
public class RemoteDetonatorItem extends Item {

    private static final String TAG_CHANNEL = "Channel";
    private static final int MAX_CHANNEL = 9;

    public RemoteDetonatorItem(Properties properties) {
        super(properties);
    }

    public static int getChannel(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.contains(TAG_CHANNEL) ? Math.floorMod(tag.getInt(TAG_CHANNEL), MAX_CHANNEL + 1) : 0;
    }

    public static void setChannel(ItemStack stack, int channel) {
        stack.getOrCreateTag().putInt(TAG_CHANNEL, Math.floorMod(channel, MAX_CHANNEL + 1));
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos();
        Player player = context.getPlayer();
        ItemStack stack = context.getItemInHand();

        if (player != null && player.isShiftKeyDown()
                && level.getBlockEntity(pos) instanceof RemoteChargeBlockEntity charge) {
            if (!level.isClientSide) {
                int channel = getChannel(stack);
                charge.setChannel(channel);
                player.displayClientMessage(
                        Component.translatable("message.apocalypsearsenal.charge_channel_set", channel),
                        true);
                level.playSound(null, pos, SoundEvents.UI_BUTTON_CLICK, SoundSource.PLAYERS, 0.8F, 1.4F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        // Sneak + right-click air: cycle channel.
        if (player.isShiftKeyDown()) {
            if (!level.isClientSide) {
                int channel = (getChannel(stack) + 1) % (MAX_CHANNEL + 1);
                setChannel(stack, channel);
                player.displayClientMessage(
                        Component.translatable("message.apocalypsearsenal.det_channel", channel), true);
                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.UI_BUTTON_CLICK, SoundSource.PLAYERS, 0.6F, 1.8F);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }

        // Normal right-click: trigger.
        if (!level.isClientSide) {
            int channel = getChannel(stack);
            int triggered = RemoteCharges.trigger((ServerLevel) level, player, channel);
            if (triggered > 0) {
                player.displayClientMessage(
                        Component.translatable("message.apocalypsearsenal.charges_triggered", triggered)
                                .withStyle(ChatFormatting.RED), true);
                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.UI_BUTTON_CLICK, SoundSource.PLAYERS, 1.0F, 0.6F);
            } else {
                player.displayClientMessage(
                        Component.translatable("message.apocalypsearsenal.no_charges", channel)
                                .withStyle(ChatFormatting.YELLOW), true);
                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.UI_BUTTON_CLICK, SoundSource.PLAYERS, 0.6F, 0.5F);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.apocalypsearsenal.detonator")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.apocalypsearsenal.detonator_channel", getChannel(stack))
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
