package com.apocalypsearsenal.item;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import com.apocalypsearsenal.Config;
import com.apocalypsearsenal.destruction.OrbitalStrikeManager;

/**
 * Planetary Annihilator — the endgame weapon.
 *
 * Aim at an area, right-click, and after a long, loud charge-up a colossal
 * energy beam descends from the sky and bores an enormous cylinder of
 * destruction into the world. Strict per-strike block caps, a long item
 * cooldown and the global strike cap keep it catastrophic but server-safe.
 */
public class PlanetaryAnnihilatorItem extends Item {

    public PlanetaryAnnihilatorItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            ServerLevel serverLevel = (ServerLevel) level;

            int range = Config.annihilatorTargetingRange();
            Vec3 start = player.getEyePosition();
            Vec3 end = start.add(player.getLookAngle().scale(range));
            BlockHitResult hit = serverLevel.clip(new ClipContext(start, end,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            Vec3 target = hit.getType() != HitResult.Type.MISS ? hit.getLocation() : end;
            target = new Vec3(target.x,
                    Mth.clamp(target.y, serverLevel.getMinBuildHeight() + 1, serverLevel.getMaxBuildHeight() - 2),
                    target.z);

            boolean ok = OrbitalStrikeManager.start(serverLevel, player, target, false, false, true);
            if (ok) {
                player.displayClientMessage(
                        Component.translatable("message.apocalypsearsenal.annihilator_charging")
                                .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), true);
                if (!player.getAbilities().instabuild) {
                    stack.hurtAndBreak(4, player, p -> p.broadcastBreakEvent(hand));
                }
                player.getCooldowns().addCooldown(this, Config.annihilatorCooldown());
            } else {
                player.displayClientMessage(
                        Component.translatable("message.apocalypsearsenal.orbital_saturated")
                                .withStyle(ChatFormatting.RED), true);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.apocalypsearsenal.annihilator")
                .withStyle(ChatFormatting.DARK_PURPLE));
        tooltip.add(Component.translatable("tooltip.apocalypsearsenal.annihilator_use")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
