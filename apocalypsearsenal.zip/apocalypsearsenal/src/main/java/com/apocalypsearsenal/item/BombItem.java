package com.apocalypsearsenal.item;

import java.util.function.Supplier;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import com.apocalypsearsenal.entity.AbstractBombEntity;

/**
 * Generic throwable bomb item: spawns the matching entity with a short
 * throw cooldown. Used for the fusion, cluster and thermobaric bombs and
 * (via subclassing) the meteor beacon.
 */
public class BombItem extends Item {

    private final Supplier<? extends EntityType<? extends AbstractBombEntity>> type;

    public BombItem(Properties properties, Supplier<? extends EntityType<? extends AbstractBombEntity>> type) {
        super(properties);
        this.type = type;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            AbstractBombEntity bomb = this.type.get().create(level);
            if (bomb != null) {
                bomb.setPos(player.getX(), player.getEyeY() - 0.15D, player.getZ());
                bomb.shoot(player.getLookAngle(), 1.15F, 0.5F);
                bomb.setFuse(bomb.defaultFuse());
                level.addFreshEntity(bomb);
                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.SNOWBALL_THROW, SoundSource.PLAYERS, 0.8F, 0.5F);
                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 0.6F, 1.0F);
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                player.getCooldowns().addCooldown(this, 10);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
