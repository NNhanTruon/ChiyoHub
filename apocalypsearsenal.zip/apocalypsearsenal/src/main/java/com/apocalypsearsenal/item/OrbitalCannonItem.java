package com.apocalypsearsenal.item;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import com.apocalypsearsenal.Config;
import com.apocalypsearsenal.destruction.OrbitalStrikeManager;

/**
 * ORBITAL STRIKE CANNON — the signature weapon of the mod.
 *
 * Right-click: raytrace (server-side only, never trusting client coordinates)
 * to pick a target, then the orbital network begins its countdown.
 * Sneak + right-click (air): cycle firing mode.
 *   - SINGLE:   one full-power strike on the aimed point.
 *   - PRECISION: faster, tighter strike for surgical demolition.
 *   - BARRAGE:  several sequential strikes scattered around the target.
 */
public class OrbitalCannonItem extends Item {

    public static final int MODE_SINGLE = 0;
    public static final int MODE_PRECISION = 1;
    public static final int MODE_BARRAGE = 2;
    private static final int MODE_COUNT = 3;

    private static final String TAG_MODE = "OrbitalMode";

    public OrbitalCannonItem(Properties properties) {
        super(properties);
    }

    public static int getMode(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.contains(TAG_MODE) ? Mth.clamp(tag.getInt(TAG_MODE), 0, MODE_COUNT - 1) : MODE_SINGLE;
    }

    public static void setMode(ItemStack stack, int mode) {
        stack.getOrCreateTag().putInt(TAG_MODE, Mth.clamp(mode, 0, MODE_COUNT - 1));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        // Mode cycling: sneak + right-click in the air.
        if (player.isShiftKeyDown()) {
            if (!level.isClientSide) {
                int mode = (getMode(stack) + 1) % MODE_COUNT;
                setMode(stack, mode);
                player.displayClientMessage(modeName(mode), true);
                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.UI_BUTTON_CLICK, SoundSource.PLAYERS, 0.6F, 1.4F);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }

        if (!level.isClientSide) {
            ServerLevel serverLevel = (ServerLevel) level;

            // Server-side target validation: pure raytrace, client never
            // sends coordinates.
            int range = Config.orbitalTargetingRange();
            Vec3 start = player.getEyePosition();
            Vec3 end = start.add(player.getLookAngle().scale(range));
            BlockHitResult hit = serverLevel.clip(new ClipContext(start, end,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            Vec3 target = hit.getType() != HitResult.Type.MISS ? hit.getLocation() : end;

            // Clamp into world bounds.
            target = new Vec3(target.x,
                    Mth.clamp(target.y, serverLevel.getMinBuildHeight() + 1, serverLevel.getMaxBuildHeight() - 2),
                    target.z);

            int mode = getMode(stack);
            boolean ok = OrbitalStrikeManager.start(serverLevel, player, target,
                    mode == MODE_BARRAGE, mode == MODE_PRECISION, false);

            if (ok) {
                player.displayClientMessage(
                        Component.translatable("message.apocalypsearsenal.orbital_incoming")
                                .withStyle(ChatFormatting.RED), true);
                if (!player.getAbilities().instabuild) {
                    stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
                }
                player.getCooldowns().addCooldown(this, Config.orbitalCooldown());
                serverLevel.playSound(null, target.x, target.y, target.z,
                        SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 3.0F, 0.5F);
            } else {
                player.displayClientMessage(
                        Component.translatable("message.apocalypsearsenal.orbital_saturated")
                                .withStyle(ChatFormatting.RED), true);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    private static Component modeName(int mode) {
        return switch (mode) {
            case MODE_PRECISION -> Component.translatable("message.apocalypsearsenal.orbital_mode.precision")
                    .withStyle(ChatFormatting.AQUA);
            case MODE_BARRAGE -> Component.translatable("message.apocalypsearsenal.orbital_mode.barrage")
                    .withStyle(ChatFormatting.GOLD);
            default -> Component.translatable("message.apocalypsearsenal.orbital_mode.single")
                    .withStyle(ChatFormatting.GREEN);
        };
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.apocalypsearsenal.orbital_cannon")
                .withStyle(ChatFormatting.LIGHT_PURPLE));
        tooltip.add(Component.translatable("tooltip.apocalypsearsenal.orbital_use")
                .withStyle(ChatFormatting.DARK_GRAY));
        tooltip.add(Component.translatable("tooltip.apocalypsearsenal.orbital_mode", modeName(getMode(stack)))
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
