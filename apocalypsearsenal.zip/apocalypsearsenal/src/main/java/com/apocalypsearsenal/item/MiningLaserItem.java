package com.apocalypsearsenal.item;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import com.apocalypsearsenal.Config;
import com.apocalypsearsenal.destruction.BlockFilter;
import com.apocalypsearsenal.destruction.DestructionManager;

import it.unimi.dsi.fastutil.longs.LongArrayList;
import org.joml.Vector3f;

/**
 * Industrial Mining Laser.
 *
 * Hold right-click for a continuous excavation beam: it bores a configurable
 * tunnel (cylinder around the look ray) out to the beam range. Removal is
 * capped per pulse and drained through the DestructionManager batch system,
 * so even a 5x5x32 tunnel per pulse never lags a tick to death. Mined
 * blocks can drop their items (see config).
 */
public class MiningLaserItem extends Item {

    public MiningLaserItem(Properties properties) {
        super(properties);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.BOW;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return ItemUtils.startUsingInstantly(level, player, hand);
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remainingTicks) {
        if (level.isClientSide || !(entity instanceof Player player)) {
            return;
        }
        if (remainingTicks % Math.max(1, Config.miningInterval()) != 0) {
            return;
        }
        if (stack.getDamageValue() >= stack.getMaxDamage()) {
            player.stopUsingItem();
            return;
        }
        firePulse((ServerLevel) level, player, stack);
    }

    private void firePulse(ServerLevel level, Player player, ItemStack stack) {
        int range = Config.miningRange();
        Vec3 start = player.getEyePosition();
        Vec3 dir = player.getLookAngle();
        Vec3 end = start.add(dir.scale(range));

        // Find where the beam hits terrain (or run to full range).
        BlockHitResult hit = level.clip(new ClipContext(start, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 beamEnd = hit.getType() != HitResult.Type.MISS ? hit.getLocation() : end;

        // ---- Collect every destroyable block within the tunnel radius ----
        double radius = Config.miningRadius();
        int cap = Config.miningMaxBlocksPerPulse();
        LongArrayList list = new LongArrayList();

        BlockPos min = BlockPos.containing(
                Math.min(start.x, beamEnd.x) - radius,
                Math.min(start.y, beamEnd.y) - radius,
                Math.min(start.z, beamEnd.z) - radius);
        BlockPos max = BlockPos.containing(
                Math.max(start.x, beamEnd.x) + radius,
                Math.max(start.y, beamEnd.y) + radius,
                Math.max(start.z, beamEnd.z) + radius);

        for (BlockPos pos : BlockPos.betweenClosed(min, max)) {
            if (distanceToSegment(Vec3.atCenterOf(pos), start, beamEnd) > radius) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            if (state.isAir() || !BlockFilter.canDestroyForMining(level, pos, state)) {
                continue;
            }
            list.add(pos.asLong());
            if (list.size() >= cap) {
                break;
            }
        }

        DestructionManager.enqueue(level, list.toLongArray(), (float) Config.miningDropChance(), null);

        // ---- Nudge/damage entities caught in the tunnel ----
        for (Entity target : level.getEntities(player,
                LaserRifleItem.boxBetween(start, beamEnd).inflate(radius))) {
            if (distanceToSegment(target.getBoundingBox().getCenter(), start, beamEnd) <= radius + 0.5D) {
                target.hurt(level.damageSources().playerAttack(player), 8.0F);
                target.igniteForSeconds(2);
            }
        }

        // ---- Visuals + sound ----
        DustParticleOptions beamColor = new DustParticleOptions(new Vector3f(1.0F, 0.7F, 0.1F), 1.5F);
        double beamLen = start.distanceTo(beamEnd);
        int step = 0;
        for (double t = 1.0D; t < beamLen; t += 1.0D) {
            Vec3 p = start.add(dir.scale(t));
            level.sendParticles(beamColor, p.x, p.y, p.z, 0, 0, 0, 0, 0);
            if (step++ % 3 == 0) {
                level.sendParticles(ParticleTypes.SMOKE, p.x, p.y, p.z, 0, 0, 0, 0, 0.01);
            }
        }
        level.sendParticles(ParticleTypes.CRIT, beamEnd.x, beamEnd.y, beamEnd.z,
                DestructionManager.count(6), 0.5D, 0.5D, 0.5D, 0.2D);
        level.sendParticles(beamColor, beamEnd.x, beamEnd.y, beamEnd.z,
                DestructionManager.count(4), 0.3D, 0.3D, 0.3D, 0.05D);
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.GUARDIAN_ATTACK, SoundSource.PLAYERS, 0.8F, 1.8F);

        // ---- Durability ----
        if (!player.getAbilities().instabuild) {
            InteractionHand hand = player.getUsedItemHand();
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
        }
    }

    /** Perpendicular distance from point p to the segment a-b. */
    static double distanceToSegment(Vec3 p, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double len2 = ab.lengthSqr();
        if (len2 < 1.0E-6D) {
            return p.distanceTo(a);
        }
        double t = Mth.clamp(p.subtract(a).dot(ab) / len2, 0.0D, 1.0D);
        return p.distanceTo(a.add(ab.scale(t)));
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.apocalypsearsenal.mining_laser")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.apocalypsearsenal.mining_use")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
