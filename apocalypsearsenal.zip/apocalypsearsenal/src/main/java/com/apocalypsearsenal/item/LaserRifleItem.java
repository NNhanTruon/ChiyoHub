package com.apocalypsearsenal.item;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import com.apocalypsearsenal.Config;
import com.apocalypsearsenal.destruction.BlockFilter;
import com.apocalypsearsenal.destruction.DestructionManager;

import it.unimi.dsi.fastutil.longs.LongArrayList;
import org.joml.Vector3f;

/**
 * High-Energy Laser Rifle.
 *
 * Hold right-click to fire continuous laser pulses. Each pulse:
 *  - damages every entity on the beam line,
 *  - vaporizes blocks along the beam path up to the per-shot cap,
 *  - carves a small crater at the impact point,
 *  - stops against unbreakable/protected blocks.
 *
 * The per-pulse interval acts as the balance cooldown; durability is
 * consumed per pulse.
 */
public class LaserRifleItem extends Item {

    private static final double BEAM_STEP = 0.5D;

    public LaserRifleItem(Properties properties) {
        super(properties);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.BOW;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return ItemUtils.startUsingInstantly(level, player, hand);
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remainingTicks) {
        if (level.isClientSide || !(entity instanceof Player player)) {
            return;
        }
        // Fire a pulse every configured interval; the first pulse is immediate.
        if (remainingTicks % Math.max(1, Config.laserPulseInterval()) != 0) {
            return;
        }
        if (stack.getDamageValue() >= stack.getMaxDamage()) {
            player.stopUsingItem();
            return;
        }
        firePulse((ServerLevel) level, player, stack);
    }

    private void firePulse(ServerLevel level, Player player, ItemStack stack) {
        int range = Config.laserRange();
        Vec3 start = player.getEyePosition();
        Vec3 dir = player.getLookAngle();
        Vec3 end = start.add(dir.scale(range));

        // ---- Walk the beam, vaporizing breakable blocks along the path ----
        LongArrayList toBreak = new LongArrayList();
        int maxBlocks = Config.laserMaxBlocksPerShot();
        int broken = 0;
        Vec3 impact = end;
        boolean stoppedByBlock = false;

        for (double t = BEAM_STEP; t <= range; t += BEAM_STEP) {
            Vec3 p = start.add(dir.scale(t));
            BlockPos pos = BlockPos.containing(p);
            if (!level.hasChunkAt(pos)) {
                impact = p;
                stoppedByBlock = true;
                break;
            }
            BlockState state = level.getBlockState(pos);
            if (!state.isAir()) {
                if (broken >= maxBlocks
                        || state.getDestroySpeed(level, pos) < 0.0F
                        || !BlockFilter.canDestroyForMining(level, pos, state)) {
                    // Beam terminated by an unbreakable/protected/over-budget block.
                    impact = p;
                    stoppedByBlock = true;
                    break;
                }
                toBreak.add(pos.asLong());
                broken++;
            }
        }

        // ---- Impact crater at the termination point ----
        double mineRadius = Config.laserMiningRadius();
        if (stoppedByBlock && mineRadius > 0.0D) {
            DestructionManager.enqueueSphere(level, impact, mineRadius, Math.max(1, maxBlocks - broken), 0.3F);
        }

        // Queue the vaporized path for budgeted removal.
        DestructionManager.enqueue(level, toBreak.toLongArray(), 0.25F, null);

        // ---- Damage entities along the beam ----
        double beamLen = start.distanceTo(impact);
        for (Entity target : level.getEntities(player, boxBetween(start, impact).inflate(1.5D))) {
            Vec3 center = target.getBoundingBox().getCenter();
            double dot = center.subtract(start).dot(dir);
            if (dot < 0.0D || dot > beamLen) {
                continue;
            }
            double perpendicular = center.distanceTo(start.add(dir.scale(dot)));
            if (perpendicular <= 1.2D) {
                target.hurt(level.damageSources().playerAttack(player), (float) Config.laserDamage());
                target.igniteForSeconds(4);
                target.setDeltaMovement(target.getDeltaMovement().add(dir.scale(0.15D)));
                target.hurtMarked = true;
            }
        }

        // ---- Visuals + sound ----
        DustParticleOptions beamColor = new DustParticleOptions(new Vector3f(1.0F, 0.1F, 0.05F), 1.5F);
        int step = 0;
        for (double t = 1.0D; t < beamLen; t += 1.0D) {
            Vec3 p = start.add(dir.scale(t));
            level.sendParticles(beamColor, p.x, p.y, p.z, 0, 0, 0, 0, 0);
            if (step++ % 4 == 0) {
                level.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 0, 0, 0, 0, 0.02);
            }
        }
        level.sendParticles(beamColor, start.x + dir.x, start.y + dir.y, start.z + dir.z, 0, 0, 0, 0, 0);

        if (stoppedByBlock || beamLen >= range - 1.0D) {
            level.sendParticles(ParticleTypes.EXPLOSION, impact.x, impact.y, impact.z,
                    DestructionManager.count(3), 0.2D, 0.2D, 0.2D, 0.0D);
            level.sendParticles(ParticleTypes.FLAME, impact.x, impact.y, impact.z,
                    DestructionManager.count(8), 0.4D, 0.4D, 0.4D, 0.1D);
            level.sendParticles(ParticleTypes.CRIT, impact.x, impact.y, impact.z,
                    DestructionManager.count(10), 0.5D, 0.5D, 0.5D, 0.2D);
        }
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.GUARDIAN_ATTACK, SoundSource.PLAYERS, 1.2F, 1.5F);

        // ---- Durability ----
        if (!player.getAbilities().instabuild) {
            InteractionHand hand = player.getUsedItemHand();
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
        }
    }

    /** Axis-aligned box between two points (handles any corner order). */
    static AABB boxBetween(Vec3 a, Vec3 b) {
        return new AABB(
                Math.min(a.x, b.x), Math.min(a.y, b.y), Math.min(a.z, b.z),
                Math.max(a.x, b.x), Math.max(a.y, b.y), Math.max(a.z, b.z));
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.apocalypsearsenal.laser_rifle")
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.apocalypsearsenal.laser_use")
                .withStyle(ChatFormatting.DARK_GRAY));
    }
}
