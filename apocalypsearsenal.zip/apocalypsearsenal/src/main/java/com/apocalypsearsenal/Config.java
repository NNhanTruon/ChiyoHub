package com.apocalypsearsenal;

import java.util.List;

import net.minecraft.util.Mth;
import net.minecraftforge.common.ForgeConfigSpec;

/**
 * Central configuration for Apocalypse Arsenal.
 *
 * Every destructive value in this mod flows through this config, and every
 * value is re-clamped on read so that even a hand-edited config file cannot
 * push the mod beyond the hard technical limits that keep the server stable.
 */
public final class Config {

    private static final ForgeConfigSpec.Builder BUILDER = new ForgeConfigSpec.Builder();

    // ------------------------------------------------------------------
    // Global destruction
    // ------------------------------------------------------------------
    public static final ForgeConfigSpec.DoubleValue GLOBAL_DESTRUCTION_MULTIPLIER;
    public static final ForgeConfigSpec.IntValue MAX_EXPLOSION_RADIUS;
    public static final ForgeConfigSpec.IntValue MAX_BLOCKS_PER_STRIKE;
    public static final ForgeConfigSpec.IntValue BLOCKS_PER_TICK;
    public static final ForgeConfigSpec.DoubleValue DROP_CHANCE;
    public static final ForgeConfigSpec.BooleanValue FIRE_ENABLED;
    public static final ForgeConfigSpec.IntValue FIRE_BLOCKS_PER_EXPLOSION;
    public static final ForgeConfigSpec.DoubleValue PARTICLE_DENSITY;
    public static final ForgeConfigSpec.DoubleValue SOUND_VOLUME;
    public static final ForgeConfigSpec.IntValue MAX_ACTIVE_STRIKES;
    public static final ForgeConfigSpec.DoubleValue RESISTANCE_CUTOFF;
    public static final ForgeConfigSpec.ConfigValue<List<String>> PROTECTED_BLOCKS;
    public static final ForgeConfigSpec.ConfigValue<List<String>> WHITELIST_BLOCKS;
    public static final ForgeConfigSpec.BooleanValue CRATER_GENERATION;
    public static final ForgeConfigSpec.ConfigValue<String> BOMB_SHAPE;

    // ------------------------------------------------------------------
    // Laser rifle
    // ------------------------------------------------------------------
    public static final ForgeConfigSpec.IntValue LASER_RANGE;
    public static final ForgeConfigSpec.IntValue LASER_PULSE_INTERVAL;
    public static final ForgeConfigSpec.DoubleValue LASER_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue LASER_MINING_RADIUS;
    public static final ForgeConfigSpec.IntValue LASER_MAX_BLOCKS_PER_SHOT;

    // ------------------------------------------------------------------
    // Industrial mining laser
    // ------------------------------------------------------------------
    public static final ForgeConfigSpec.IntValue MINING_LASER_RANGE;
    public static final ForgeConfigSpec.IntValue MINING_LASER_INTERVAL;
    public static final ForgeConfigSpec.DoubleValue MINING_RADIUS;
    public static final ForgeConfigSpec.IntValue MINING_MAX_BLOCKS_PER_PULSE;
    public static final ForgeConfigSpec.DoubleValue MINING_DROP_CHANCE;

    // ------------------------------------------------------------------
    // Bombs
    // ------------------------------------------------------------------
    public static final ForgeConfigSpec.IntValue FUSION_RADIUS;
    public static final ForgeConfigSpec.IntValue FUSION_FUSE;
    public static final ForgeConfigSpec.IntValue CLUSTER_COUNT;
    public static final ForgeConfigSpec.IntValue CLUSTER_SPREAD;
    public static final ForgeConfigSpec.IntValue CLUSTER_SECONDARY_RADIUS;
    public static final ForgeConfigSpec.IntValue CLUSTER_CHARGE_FUSE;
    public static final ForgeConfigSpec.IntValue THERMOBARIC_RADIUS;
    public static final ForgeConfigSpec.IntValue THERMOBARIC_FUSE;
    public static final ForgeConfigSpec.IntValue THERMOBARIC_SECONDARIES;
    public static final ForgeConfigSpec.IntValue THERMOBARIC_SECONDARY_RADIUS;

    // ------------------------------------------------------------------
    // Meteor strikes
    // ------------------------------------------------------------------
    public static final ForgeConfigSpec.IntValue METEOR_RADIUS;
    public static final ForgeConfigSpec.IntValue METEOR_COUNTDOWN;
    public static final ForgeConfigSpec.IntValue METEOR_SPAWN_HEIGHT;

    // ------------------------------------------------------------------
    // Orbital Strike Cannon
    // ------------------------------------------------------------------
    public static final ForgeConfigSpec.IntValue ORBITAL_RADIUS;
    public static final ForgeConfigSpec.IntValue ORBITAL_COUNTDOWN;
    public static final ForgeConfigSpec.IntValue ORBITAL_STRIKE_COUNT;
    public static final ForgeConfigSpec.IntValue ORBITAL_STRIKE_INTERVAL;
    public static final ForgeConfigSpec.IntValue ORBITAL_BARRAGE_SPREAD;
    public static final ForgeConfigSpec.IntValue ORBITAL_COOLDOWN;
    public static final ForgeConfigSpec.IntValue ORBITAL_BEAM_WIDTH;
    public static final ForgeConfigSpec.DoubleValue ORBITAL_DAMAGE;
    public static final ForgeConfigSpec.IntValue ORBITAL_TARGETING_RANGE;
    public static final ForgeConfigSpec.IntValue ORBITAL_MAX_BLOCKS_PER_STRIKE;

    // ------------------------------------------------------------------
    // Planetary Annihilator
    // ------------------------------------------------------------------
    public static final ForgeConfigSpec.IntValue ANNIHILATOR_RADIUS;
    public static final ForgeConfigSpec.IntValue ANNIHILATOR_COUNTDOWN;
    public static final ForgeConfigSpec.IntValue ANNIHILATOR_COOLDOWN;
    public static final ForgeConfigSpec.DoubleValue ANNIHILATOR_DAMAGE;
    public static final ForgeConfigSpec.IntValue ANNIHILATOR_MAX_BLOCKS_PER_STRIKE;
    public static final ForgeConfigSpec.IntValue ANNIHILATOR_TARGETING_RANGE;

    // ------------------------------------------------------------------
    // Remote detonation
    // ------------------------------------------------------------------
    public static final ForgeConfigSpec.IntValue REMOTE_CHARGE_RADIUS;
    public static final ForgeConfigSpec.IntValue REMOTE_MAX_CHARGES_PER_TRIGGER;
    public static final ForgeConfigSpec.IntValue REMOTE_TRIGGER_RANGE;

    public static final ForgeConfigSpec SPEC;

    static {
        BUILDER.comment("Apocalypse Arsenal configuration. All values are re-clamped on use,",
                        "so out-of-range values in this file can never break the server.").push("global");

        GLOBAL_DESTRUCTION_MULTIPLIER = BUILDER
                .comment("Global multiplier applied to every explosion radius. 2.0 = twice the destruction.")
                .defineInRange("globalDestructionMultiplier", 1.0, 0.1, 4.0);
        MAX_EXPLOSION_RADIUS = BUILDER
                .comment("HARD SAFETY CAP: the largest radius (in blocks) any single explosion may reach,",
                         "regardless of weapon or multiplier. Lower this on weak servers.")
                .defineInRange("maxExplosionRadius", 32, 4, 64);
        MAX_BLOCKS_PER_STRIKE = BUILDER
                .comment("HARD SAFETY CAP: maximum blocks one strike may destroy (memory/performance budget).")
                .defineInRange("maxBlocksPerStrike", 60000, 256, 250000);
        BLOCKS_PER_TICK = BUILDER
                .comment("Server-side budget: how many blocks are removed per tick by queued destruction batches.")
                .defineInRange("blocksPerTick", 2048, 64, 16384);
        DROP_CHANCE = BUILDER
                .comment("Chance that a block destroyed by a large explosion drops its item. 0 = no drops (fast).")
                .defineInRange("dropChance", 0.12, 0.0, 1.0);
        FIRE_ENABLED = BUILDER
                .comment("Whether explosions and strikes may leave persistent fire behind.")
                .define("fireEnabled", true);
        FIRE_BLOCKS_PER_EXPLOSION = BUILDER
                .comment("Maximum number of fire blocks placed around one explosion crater.")
                .defineInRange("fireBlocksPerExplosion", 48, 0, 256);
        PARTICLE_DENSITY = BUILDER
                .comment("Multiplier for particle counts (0.1 = minimal, 2.0 = cinematic).")
                .defineInRange("particleDensity", 1.0, 0.1, 2.0);
        SOUND_VOLUME = BUILDER
                .comment("Multiplier for explosion/strike sound volume.")
                .defineInRange("soundVolume", 1.0, 0.1, 2.0);
        MAX_ACTIVE_STRIKES = BUILDER
                .comment("Maximum number of orbital/annihilator strikes running at the same time.")
                .defineInRange("maxActiveStrikes", 8, 1, 32);
        RESISTANCE_CUTOFF = BUILDER
                .comment("Blocks with a blast resistance above this value are immune to destruction.",
                         "Vanilla: dirt 0.5, stone 6, obsidian 1200. Default 1200 lets obsidian be destroyed.")
                .defineInRange("resistanceCutoff", 1200.0, 0.0, 3600000.0);
        PROTECTED_BLOCKS = BUILDER
                .comment("Blocks that can never be destroyed, regardless of other settings.",
                         "Unbreakable blocks (bedrock, barriers...) are always protected implicitly.")
                .defineList("protectedBlocks",
                        List.of("minecraft:bedrock", "minecraft:barrier", "minecraft:command_block",
                                "minecraft:chain_command_block", "minecraft:repeating_command_block",
                                "minecraft:structure_block", "minecraft:structure_void",
                                "minecraft:end_portal", "minecraft:end_portal_frame",
                                "minecraft:nether_portal", "minecraft:reinforced_deepslate",
                                "minecraft:jigsaw"),
                        o -> o instanceof String);
        WHITELIST_BLOCKS = BUILDER
                .comment("If non-empty, ONLY these blocks may be destroyed by explosions (plus mining tools).",
                         "Example: [\"minecraft:stone\", \"minecraft:dirt\"]")
                .defineList("whitelistBlocks", List.of(), o -> o instanceof String);
        CRATER_GENERATION = BUILDER
                .comment("Whether major explosions dig craters (deeper destruction below ground level).")
                .define("craterGeneration", true);
        BOMB_SHAPE = BUILDER
                .comment("Destruction zone shape for the bomb family (fusion/thermobaric/meteor/remote).",
                         "Allowed: sphere, cylinder, cuboid. Orbital strikes always use cylinder.")
                .define("bombShape", "sphere");

        BUILDER.pop();

        // ------------------------------------------------------------------
        BUILDER.comment("Laser rifle settings").push("laser");

        LASER_RANGE = BUILDER
                .comment("Maximum beam range in blocks.")
                .defineInRange("laserRange", 96, 16, 256);
        LASER_PULSE_INTERVAL = BUILDER
                .comment("Ticks between laser pulses while the trigger is held (the cooldown between shots).")
                .defineInRange("laserPulseInterval", 8, 1, 40);
        LASER_DAMAGE = BUILDER
                .comment("Damage per pulse to entities in the beam. 30 one-shots most hostile mobs.")
                .defineInRange("laserDamage", 30.0, 1.0, 500.0);
        LASER_MINING_RADIUS = BUILDER
                .comment("Radius of the blast crater carved at the beam impact point. 0 disables.")
                .defineInRange("laserMiningRadius", 1.5, 0.0, 4.0);
        LASER_MAX_BLOCKS_PER_SHOT = BUILDER
                .comment("Maximum blocks a single pulse may vaporize along its path.")
                .defineInRange("laserMaxBlocksPerShot", 64, 1, 2048);

        BUILDER.pop();

        // ------------------------------------------------------------------
        BUILDER.comment("Industrial mining laser settings").push("miningLaser");

        MINING_LASER_RANGE = BUILDER
                .comment("Maximum mining beam range in blocks.")
                .defineInRange("miningLaserRange", 32, 8, 128);
        MINING_LASER_INTERVAL = BUILDER
                .comment("Ticks between mining pulses while the trigger is held.")
                .defineInRange("miningLaserInterval", 4, 1, 20);
        MINING_RADIUS = BUILDER
                .comment("Tunnel radius in blocks (2.0 digs a 5x5 tunnel).")
                .defineInRange("miningRadius", 2.0, 0.5, 4.0);
        MINING_MAX_BLOCKS_PER_PULSE = BUILDER
                .comment("Maximum blocks removed per pulse (keeps per-tick cost bounded).")
                .defineInRange("miningMaxBlocksPerPulse", 256, 1, 4096);
        MINING_DROP_CHANCE = BUILDER
                .comment("Chance for mined blocks to drop their items.")
                .defineInRange("miningDropChance", 0.3, 0.0, 1.0);

        BUILDER.pop();

        // ------------------------------------------------------------------
        BUILDER.comment("Bomb family settings").push("bombs");

        FUSION_RADIUS = BUILDER
                .comment("Fusion bomb blast radius (blocks).")
                .defineInRange("fusionRadius", 12, 2, 32);
        FUSION_FUSE = BUILDER
                .comment("Fusion bomb fuse length in ticks after being thrown (20 ticks = 1 second).")
                .defineInRange("fusionFuse", 80, 20, 600);
        CLUSTER_COUNT = BUILDER
                .comment("Number of secondary charges a cluster bomb splits into.")
                .defineInRange("clusterCount", 12, 2, 32);
        CLUSTER_SPREAD = BUILDER
                .comment("How far secondary charges scatter (blocks).")
                .defineInRange("clusterSpread", 6, 1, 16);
        CLUSTER_SECONDARY_RADIUS = BUILDER
                .comment("Blast radius of each secondary cluster charge.")
                .defineInRange("clusterSecondaryRadius", 4, 1, 10);
        CLUSTER_CHARGE_FUSE = BUILDER
                .comment("Average fuse of secondary charges in ticks.")
                .defineInRange("clusterChargeFuse", 25, 10, 100);
        THERMOBARIC_RADIUS = BUILDER
                .comment("Thermobaric bomb main blast radius.")
                .defineInRange("thermobaricRadius", 16, 4, 48);
        THERMOBARIC_FUSE = BUILDER
                .comment("Thermobaric bomb fuse length in ticks.")
                .defineInRange("thermobaricFuse", 100, 20, 600);
        THERMOBARIC_SECONDARIES = BUILDER
                .comment("Number of delayed secondary detonations after the main blast (0 = off).")
                .defineInRange("thermobaricSecondaries", 4, 0, 8);
        THERMOBARIC_SECONDARY_RADIUS = BUILDER
                .comment("Radius of each delayed secondary detonation.")
                .defineInRange("thermobaricSecondaryRadius", 5, 1, 16);

        BUILDER.pop();

        // ------------------------------------------------------------------
        BUILDER.comment("Meteor strike settings").push("meteor");

        METEOR_RADIUS = BUILDER
                .comment("Meteor impact explosion radius.")
                .defineInRange("meteorRadius", 10, 2, 24);
        METEOR_COUNTDOWN = BUILDER
                .comment("Ticks after the beacon lands before the meteor is called down.")
                .defineInRange("meteorCountdown", 100, 20, 600);
        METEOR_SPAWN_HEIGHT = BUILDER
                .comment("How high above the beacon the meteor spawns (blocks).")
                .defineInRange("meteorSpawnHeight", 100, 30, 200);

        BUILDER.pop();

        // ------------------------------------------------------------------
        BUILDER.comment("Orbital Strike Cannon settings").push("orbital");

        ORBITAL_RADIUS = BUILDER
                .comment("Blast radius of a single orbital strike.")
                .defineInRange("orbitalRadius", 16, 4, 32);
        ORBITAL_COUNTDOWN = BUILDER
                .comment("Countdown ticks between targeting and impact (3 seconds by default).")
                .defineInRange("orbitalCountdown", 60, 20, 400);
        ORBITAL_STRIKE_COUNT = BUILDER
                .comment("Number of sequential strikes fired in BARRAGE mode.")
                .defineInRange("orbitalStrikeCount", 3, 1, 10);
        ORBITAL_STRIKE_INTERVAL = BUILDER
                .comment("Ticks between sequential strikes in BARRAGE mode.")
                .defineInRange("orbitalStrikeInterval", 25, 5, 100);
        ORBITAL_BARRAGE_SPREAD = BUILDER
                .comment("Random offset radius around the marked point for BARRAGE strikes (blocks).")
                .defineInRange("orbitalBarrageSpread", 6, 1, 24);
        ORBITAL_COOLDOWN = BUILDER
                .comment("Item cooldown ticks after firing (1200 = 60 seconds).")
                .defineInRange("orbitalCooldown", 1200, 100, 72000);
        ORBITAL_BEAM_WIDTH = BUILDER
                .comment("Visual thickness of the targeting/impact beam (1-5).")
                .defineInRange("orbitalBeamWidth", 2, 1, 5);
        ORBITAL_DAMAGE = BUILDER
                .comment("Maximum entity damage at the center of an orbital strike.")
                .defineInRange("orbitalDamage", 250.0, 10.0, 2000.0);
        ORBITAL_TARGETING_RANGE = BUILDER
                .comment("Maximum targeting distance from the player (blocks).")
                .defineInRange("orbitalTargetingRange", 192, 16, 512);
        ORBITAL_MAX_BLOCKS_PER_STRIKE = BUILDER
                .comment("Per-strike block destruction cap for orbital strikes (lower than the global cap).")
                .defineInRange("orbitalMaxBlocksPerStrike", 30000, 1024, 250000);

        BUILDER.pop();

        // ------------------------------------------------------------------
        BUILDER.comment("Planetary Annihilator settings").push("annihilator");

        ANNIHILATOR_RADIUS = BUILDER
                .comment("Annihilator blast radius. Hard-capped by maxExplosionRadius.")
                .defineInRange("annihilatorRadius", 24, 8, 48);
        ANNIHILATOR_COUNTDOWN = BUILDER
                .comment("Charge-up time in ticks before the annihilator beam fires (200 = 10 seconds).")
                .defineInRange("annihilatorCountdown", 200, 40, 1200);
        ANNIHILATOR_COOLDOWN = BUILDER
                .comment("Item cooldown ticks after firing (6000 = 5 minutes).")
                .defineInRange("annihilatorCooldown", 6000, 200, 72000);
        ANNIHILATOR_DAMAGE = BUILDER
                .comment("Maximum entity damage at the beam impact center.")
                .defineInRange("annihilatorDamage", 1000.0, 100.0, 2000.0);
        ANNIHILATOR_MAX_BLOCKS_PER_STRIKE = BUILDER
                .comment("Strict per-strike block destruction cap for the annihilator.")
                .defineInRange("annihilatorMaxBlocksPerStrike", 80000, 1024, 250000);
        ANNIHILATOR_TARGETING_RANGE = BUILDER
                .comment("Maximum targeting distance from the player (blocks).")
                .defineInRange("annihilatorTargetingRange", 256, 16, 512);

        BUILDER.pop();

        // ------------------------------------------------------------------
        BUILDER.comment("Remote detonation settings").push("remote");

        REMOTE_CHARGE_RADIUS = BUILDER
                .comment("Blast radius of one remote charge.")
                .defineInRange("remoteChargeRadius", 6, 1, 16);
        REMOTE_MAX_CHARGES_PER_TRIGGER = BUILDER
                .comment("Maximum charges detonated by one click of the detonator.")
                .defineInRange("remoteMaxChargesPerTrigger", 16, 1, 64);
        REMOTE_TRIGGER_RANGE = BUILDER
                .comment("Range (blocks) in which the detonator finds linked charges.")
                .defineInRange("remoteTriggerRange", 128, 16, 512);

        BUILDER.pop();

        SPEC = BUILDER.build();
    }

    private Config() {
    }

    // ------------------------------------------------------------------
    // Clamped convenience getters (used at effect time, not registration time)
    // ------------------------------------------------------------------

    public static double globalMultiplier() {
        return Mth.clamp(GLOBAL_DESTRUCTION_MULTIPLIER.get(), 0.1, 4.0);
    }

    public static double maxExplosionRadius() {
        return Mth.clamp(MAX_EXPLOSION_RADIUS.get(), 2, 64);
    }

    public static int maxBlocksPerStrike() {
        return Mth.clamp(MAX_BLOCKS_PER_STRIKE.get(), 256, 250000);
    }

    public static int blocksPerTick() {
        return Mth.clamp(BLOCKS_PER_TICK.get(), 64, 16384);
    }

    public static double dropChance() {
        return Mth.clamp(DROP_CHANCE.get(), 0.0, 1.0);
    }

    public static int fireBlocks() {
        return Mth.clamp(FIRE_BLOCKS_PER_EXPLOSION.get(), 0, 256);
    }

    public static double particleDensity() {
        return Mth.clamp(PARTICLE_DENSITY.get(), 0.1, 2.0);
    }

    public static double soundVolume() {
        return Mth.clamp(SOUND_VOLUME.get(), 0.1, 2.0);
    }

    public static int maxActiveStrikes() {
        return Mth.clamp(MAX_ACTIVE_STRIKES.get(), 1, 32);
    }

    public static double resistanceCutoff() {
        return Mth.clamp(RESISTANCE_CUTOFF.get(), 0.0, 3600000.0);
    }

    public static boolean cratersEnabled() {
        return CRATER_GENERATION.get();
    }

    public static int laserRange() {
        return Mth.clamp(LASER_RANGE.get(), 16, 256);
    }

    public static int laserPulseInterval() {
        return Mth.clamp(LASER_PULSE_INTERVAL.get(), 1, 40);
    }

    public static double laserDamage() {
        return Mth.clamp(LASER_DAMAGE.get(), 1.0, 500.0);
    }

    public static double laserMiningRadius() {
        return Mth.clamp(LASER_MINING_RADIUS.get(), 0.0, 4.0);
    }

    public static int laserMaxBlocksPerShot() {
        return Mth.clamp(LASER_MAX_BLOCKS_PER_SHOT.get(), 1, 2048);
    }

    public static int miningRange() {
        return Mth.clamp(MINING_LASER_RANGE.get(), 8, 128);
    }

    public static int miningInterval() {
        return Mth.clamp(MINING_LASER_INTERVAL.get(), 1, 20);
    }

    public static double miningRadius() {
        return Mth.clamp(MINING_RADIUS.get(), 0.5, 4.0);
    }

    public static int miningMaxBlocksPerPulse() {
        return Mth.clamp(MINING_MAX_BLOCKS_PER_PULSE.get(), 1, 4096);
    }

    public static double miningDropChance() {
        return Mth.clamp(MINING_DROP_CHANCE.get(), 0.0, 1.0);
    }

    public static double fusionRadius() {
        return Mth.clamp(FUSION_RADIUS.get(), 2, 32);
    }

    public static int fusionFuse() {
        return Mth.clamp(FUSION_FUSE.get(), 20, 600);
    }

    public static int clusterCount() {
        return Mth.clamp(CLUSTER_COUNT.get(), 2, 32);
    }

    public static double clusterSpread() {
        return Mth.clamp(CLUSTER_SPREAD.get(), 1, 16);
    }

    public static double clusterSecondaryRadius() {
        return Mth.clamp(CLUSTER_SECONDARY_RADIUS.get(), 1, 10);
    }

    public static int clusterChargeFuse() {
        return Mth.clamp(CLUSTER_CHARGE_FUSE.get(), 10, 100);
    }

    public static double thermobaricRadius() {
        return Mth.clamp(THERMOBARIC_RADIUS.get(), 4, 48);
    }

    public static int thermobaricFuse() {
        return Mth.clamp(THERMOBARIC_FUSE.get(), 20, 600);
    }

    public static int thermobaricSecondaries() {
        return Mth.clamp(THERMOBARIC_SECONDARIES.get(), 0, 8);
    }

    public static double thermobaricSecondaryRadius() {
        return Mth.clamp(THERMOBARIC_SECONDARY_RADIUS.get(), 1, 16);
    }

    public static double meteorRadius() {
        return Mth.clamp(METEOR_RADIUS.get(), 2, 24);
    }

    public static int meteorCountdown() {
        return Mth.clamp(METEOR_COUNTDOWN.get(), 20, 600);
    }

    public static int meteorSpawnHeight() {
        return Mth.clamp(METEOR_SPAWN_HEIGHT.get(), 30, 200);
    }

    public static double orbitalRadius() {
        return Mth.clamp(ORBITAL_RADIUS.get(), 4, 32);
    }

    public static int orbitalCountdown() {
        return Mth.clamp(ORBITAL_COUNTDOWN.get(), 20, 400);
    }

    public static int orbitalStrikeCount() {
        return Mth.clamp(ORBITAL_STRIKE_COUNT.get(), 1, 10);
    }

    public static int orbitalStrikeInterval() {
        return Mth.clamp(ORBITAL_STRIKE_INTERVAL.get(), 5, 100);
    }

    public static double orbitalBarrageSpread() {
        return Mth.clamp(ORBITAL_BARRAGE_SPREAD.get(), 1, 24);
    }

    public static int orbitalCooldown() {
        return Mth.clamp(ORBITAL_COOLDOWN.get(), 100, 72000);
    }

    public static int orbitalBeamWidth() {
        return Mth.clamp(ORBITAL_BEAM_WIDTH.get(), 1, 5);
    }

    public static double orbitalDamage() {
        return Mth.clamp(ORBITAL_DAMAGE.get(), 10.0, 2000.0);
    }

    public static int orbitalTargetingRange() {
        return Mth.clamp(ORBITAL_TARGETING_RANGE.get(), 16, 512);
    }

    public static int orbitalMaxBlocksPerStrike() {
        return Mth.clamp(ORBITAL_MAX_BLOCKS_PER_STRIKE.get(), 1024, 250000);
    }

    public static double annihilatorRadius() {
        return Mth.clamp(ANNIHILATOR_RADIUS.get(), 8, 48);
    }

    public static int annihilatorCountdown() {
        return Mth.clamp(ANNIHILATOR_COUNTDOWN.get(), 40, 1200);
    }

    public static int annihilatorCooldown() {
        return Mth.clamp(ANNIHILATOR_COOLDOWN.get(), 200, 72000);
    }

    public static double annihilatorDamage() {
        return Mth.clamp(ANNIHILATOR_DAMAGE.get(), 100.0, 2000.0);
    }

    public static int annihilatorMaxBlocksPerStrike() {
        return Mth.clamp(ANNIHILATOR_MAX_BLOCKS_PER_STRIKE.get(), 1024, 250000);
    }

    public static int annihilatorTargetingRange() {
        return Mth.clamp(ANNIHILATOR_TARGETING_RANGE.get(), 16, 512);
    }

    public static double remoteChargeRadius() {
        return Mth.clamp(REMOTE_CHARGE_RADIUS.get(), 1, 16);
    }

    public static int remoteMaxChargesPerTrigger() {
        return Mth.clamp(REMOTE_MAX_CHARGES_PER_TRIGGER.get(), 1, 64);
    }

    public static double remoteTriggerRange() {
        return Mth.clamp(REMOTE_TRIGGER_RANGE.get(), 16, 512);
    }
}
